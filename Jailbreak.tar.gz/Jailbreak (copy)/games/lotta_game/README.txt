-This is a game for Minetest that will add Lord Of the Rings like elements into the game. It is currently in beta form which means that the main features are completed, however there will be some bugs here and there so please report them. This game will be updated every month and during some festivals (aka special releases) during which further stuff will be added in.
-Licence:
Mods starting with "lott...": "CC BY-SA 3.0"
Other mods: refer to the README in that mod
AspireMint Models: "CC BY-SA 3.0"
-----------------------------------------------------------------------------------------------
-(Version Beta 1409.00)
Naming convention taken from Voxelands
-Changelog (Newest Commit to Oldest)
-Decoration Blocks Added (catninja)
-Added screwdriver redo mod (Made by TenPlus)
-Craft Guides Added (fishyWET)
-Inventory GUI Changes [lottinventory] (fishyWET)
-Lottpotions Revamp (fishyWET)
-Decoration Blocks & Bugfixes to Skeleton (Amaz)
-Inventory/ Chests Background Images (Flipsels)
-Lottclothes added (Flipsels)
-Hatches added (catninja)
-Pearl texture changed (Flipsels)
-Texture changes of Tin (Flipsels)
-Banners Added [Uncraftable] (fishyWET)
-Fancy Hud Added & Hunger (Amaz)
-----------------------------------------------------------------------------------------------
Developers/ Helpers:
fishyWET(Primary Developer)
Amaz (Secondary Developer)
Flipsels (Developer)
catninja (Contributor)
More Contributors wanted, just send me a PM
-----------------------------------------------------------------------------------------------
Credits:
(People whom i modify their code/ use their textures to make this game possible)
(Not in Any Order)
Topywo (Sea Ores)
Pilzadam (Troll Model, farming, mobs, Bed code & texture, throwing)
Doc (farming)
Ironzorg, VanessaE (flowers/ plants)
Sapier (Balrog Model, Re-texture of his balrog texture)
Paramat (Trees, mapgen)
Stu (Dwarf & Elf & Human model, Armor, npc framework)
Traxie21 (Potions)
AMMOnym (Some of the mobs textures)
0gb.us (https://forum.minetest.net/viewtopic.php?id=3876)Inventory_plus )
Cornernote (https://forum.minetest.net/viewtopic.php?id=3876)Inventory_plus )
rubenwardy (Cake Nodeblock) (2014, Anniversary Update)
Dan Duncombe (Paxel) (2014, Anniversary Update)
Chinchow (Spawning Structures)
BrandonReese(Sword wearing, chest contents, mobs behaviour)
Zeg9 (craft guide)
Sapier (Mobf) (2014 Easter)
Sokomine (mobf_rabbit) (2014 Easter)
Blockmen (hud)
ak399g (Ithildin)
Tonyka (Tables & chairs in lottblocks)
brunob.santos (Desert Cobble)
Dan Duncombe (Generating Structures, banners)
krupnovpavel (Mob Riding)
Calinou (Inventory GUI)
TenPlus1 (Screwdriver redo)
-----------------------------------------------------------------------------------------------
