Lucky Block mod [lucky_block]

This mod adds a new and exciting block to the game which when broken can give
the player something good, surprising, bad, hurtful or just simply a troll.

Lucky Blocks can be crafted with 1 chest surrounded by gold ingots.

The api.txt document shows how to add your own blocks to the list by using
one of the 9 commands included and the blocks.lua file gives you many examples
by using some of the popular mods available.

https://forum.minetest.net/viewtopic.php?f=9&t=13284

Released under WTFPL

0.1 - Initial release
0.2 - New api commands added thanks to blert2112
0.3 - New blocks added, also error checking, new options and schematic rehaul
