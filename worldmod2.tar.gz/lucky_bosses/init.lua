local path = minetest.get_modpath("lucky_bosses")
dofile(path.."/api.lua")



lucky_bosses:register_mob("lucky_bosses:dragon", {
	type = "monster",
	hp_max = 833,
	hp_min = 733,
	collisionbox = {-1, 0, -1, 1, 5, 1},
	visual = "mesh",
	mesh = "mese_dragon.x",
	textures = {{"mese_dragon.png"}},
	visual_size = {x=12, y=12},
	makes_footstep_sound = true,
	maxus = true,
	view_range = 45,
  rotate = 270,
	walk_velocity = 2,
	run_velocity = 4,
    sounds = {
		shoot_attack = "mesed",
		attack = "mese_dragon",
		distance = 70,
	},
	damage = 86,
	jump = true,
	jump_height = 15,
  putter = true,
	drops = {
		{name = "default:meseblock",
		chance = 1,
		min = 1,
		max = 1},
		{name = "default:diamond",
		chance = 1,
		min = 5,
		max = 35},
		{name = "lucky_weapons:destroyer",
		chance = 1,
		min = 1,
		max = 1},
    },
	armor = 90,
	drawtype = "front",
	water_damage = 0,
	lava_damage = 0,
	light_damage = 0,
	on_rightclick = nil,
	attack_type = "dogshoot",
	dogshoot_stop = true,
	arrow = "lucky_bosses:dragonball",
	reach = 5,
	shoot_interval = 3,
	shoot_offset = -1,
	animation = {
		speed_normal = 15,
		speed_run = 25,
		stand_start = 60,
		stand_end = 120,
		walk_start = 161,
		walk_end = 205,
		run_start = 206,
		run_end = 242,
		punch_start = 242,
		punch_end = 275,
		punch1_start = 330,
		punch1_end = 370,
    dattack_start = 120,
    dattack_end = 160,
    }
})
lucky_bosses:register_mob("lucky_bosses:lava_titan", {
	type = "monster",
	hp_max = 780,
	hp_min = 780,
	collisionbox = {-0.6, -0.05, -0.6, 0.6, 4.0, 0.6},
	visual = "mesh",
	mesh = "lava_titan.x",
	textures = {{"lava_titan.png"}},
	visual_size = {x=4, y=4},
	makes_footstep_sound = true,
	view_range = 20,
	lifetimer = 500,
	walk_velocity = 1,
	run_velocity = 2,
	floats = 1,
  sounds = {
		random = "lava_titan",
	},
	damage = 74,
	jump = false,
	jump_height=0,
	drops = {
		{name = "default:diamond",
		chance = 1,
		min = 7,
		max = 9,},
		{name = "lucky_weapons:firebrand",
		chance = 1,
		min = 1,
		max = 1,},
		{name = "lucky_weapons:dagger_diamond",
		chance = 2,
		min = 1,
		max = 3,},
	},
	armor = 90,
	drawtype = "front",
	water_damage = 4,
  rotate = 270,
  digger = true,
	melter = true,
	light_damage = 0,
	lava_damage = 0,
	on_rightclick = nil,
	floats = 1,
	attack_type = "dogshoot",
	dogshoot_stop = true,
  arrow = "lucky_bosses:titanball",
  reach = 6,
  shoot_interval = 2,
  shoot_offset = -1,
	true_dist_attack = true,
	on_dist_attack = function(self, player)
		local pos = player:getpos()
		for dy=-1, 6, 1 do
			for dx=-1, 1, 2 do
				for dz=-1, 1, 2 do
					local p = {x=pos.x+dx, y=pos.y+dy, z=pos.z+dz}
					local n = minetest.env:get_node(p).name
					if n~="default:lava_flowing" then
						minetest.set_node(p, {name="default:lava_flowing"})
					end
				end
			end
		end
	end,
	animation = {
		speed_normal = 25,
		speed_run = 25,
		stand_start = 120,
		stand_end = 300,
		walk_start = 10,
		walk_end = 110,
		run_start = 10,
		run_end = 110,
		punch_start = 301,
		punch_end = 340,
    dattack_start =340,
    dattack_end=400,
	}
})
-- titanball
lucky_bosses:register_arrow("lucky_bosses:titanball", {
	visual = "sprite",
	visual_size = {x = 1, y = 1},
	textures = {"duck_egg.png"},
	velocity = 15,
	-- direct hit
	hit_player = function(self, player)
		lucky_bosses:lava_explosion(pos, player)
	end,
	hit_player = function(self, player)
		player:punch(self.object, 1.0, {
			full_punch_interval = 1.0,
			damage_groups = {fleshy = 2},
		}, nil)
	end,
	hit_mob = function(self, player)
		lucky_bosses:lava_explosion(pos, player)
	end,

})

function lucky_bosses:lava_explosion(pos, player)
--    for i=pos.x-1, pos.x+1, 1 do
		pos = player:getpos()
		for j=pos.y-1, pos.y+6, 1 do
			minetest.set_node({x=pos.x+1, y=j, z=pos.z+1}, {name="default:lava_source"})
			minetest.set_node({x=pos.x+1, y=j, z=pos.z-1}, {name="default:lava_source"})
			minetest.set_node({x=pos.x-1, y=j, z=pos.z+1}, {name="default:lava_source"})
			minetest.set_node({x=pos.x-1, y=j, z=pos.z-1}, {name="default:lava_source"})

		end
end
lucky_bosses:register_arrow("lucky_bosses:dragonball", {
	visual = "sprite",
	visual_size = {x = 1, y = 1},
	textures = {"transparent.png"},
	velocity = 10,
	remover = true,
	-- direct hit
	hit_player = function(self, player)
		player:punch(self.object, 1.0, {
			full_punch_interval = 1.0,
			damage_groups = {fleshy = 3},
		}, nil)
	end,

	hit_mob = function(self, player)
		player:punch(self.object, 1.0, {
			full_punch_interval = 1.0,
			damage_groups = {fleshy = 3},
		}, nil)
	end,
	hit_player = function(self, player)
		lucky_bosses:duck_explosion_direct(pos, player)
end
})
function lucky_bosses:duck_explosion_direct(pos, player)
		pos = player:getpos()
		pos.y = pos.y+1;
		minetest.add_particlespawner({
			amount = 10,
			time = 0.2,
			minpos = {x=pos.x-1, y=pos.y-1, z=pos.z-1},
			maxpos = {x=pos.x+1, y=pos.y+4, z=pos.z+1},
			minvel = {x=0, y=0, z=0},
			maxvel = {x=1, y=1, z=1},
			minacc = {x=-0.5,y=5,z=-0.5},
			maxacc = {x=0.5,y=5,z=0.5},
			minexptime = 1,
			maxexptime = 3,
			minsize = 4,
			maxsize = 6,
			collisiondetection = false,
			vertical = false,
			texture = "zap.png",
		})
		core.after(0.4, function()
			for dx = -2,2 do
				pos = {x = pos.x+dx, y=pos.y; z=pos.z+dx}
				minetest.add_particlespawner({
					amount = 100,
					time = 0.2,
					minpos = {x=pos.x-1, y=pos.y-1, z=pos.z-1},
					maxpos = {x=pos.x+1, y=pos.y+4, z=pos.z+1},
					minvel = {x=0, y=0, z=0},
					maxvel = {x=1, y=5, z=1},
					minacc = {x=-0.5,y=5,z=-0.5},
					maxacc = {x=0.5,y=5,z=0.5},
					minexptime = 1,
					maxexptime = 3,
					minsize = 2,
					maxsize = 4,
					collisiondetection = false,
					vertical = false,
					texture = "fire.png",
				})
				minetest.add_entity(pos, "lucky_bosses:dragon_minor")
			end
		end)
	end
lucky_bosses:register_mob("lucky_bosses:dragon_minor", {
	type = "monster",
	hp_max = 75,
	hp_min = 25,
	collisionbox = {-0.8, -0.85, -0.8, 0.8, 1.9, 0.8},
	visual = "mesh",
	mesh = "manticore.x",
	textures = {{"manticore.png"}},
	visual_size = {x=4, y=4},
	makes_footstep_sound = true,
	view_range = 25,
	walk_velocity = 2,
	run_velocity = 4,
  sounds = {
		random = "manticore",
	},
	damage = 4,
	jump = true,
	drops = {
		{name = "default:diamond",
		chance = 1,
		min = 0,
		max = 4,},
		{name = "default:steelblock",
		chance = 3,
		min = 0,
		max = 5,},
	},
	armor = 100,
	drawtype = "front",
	water_damage = 2,
  rotate = 270,
	lava_damage = 5,
	light_damage = 0,
	on_rightclick = nil,
	attack_type = "dogshoot",
	dogshoot_stop = true,
    arrow = "lucky_bosses:spine",
    reach = 3,
    shoot_interval = 2,
    shoot_offset = 1,
	animation = {
		speed_normal = 25,
		speed_run = 25,
		stand_start = 1,
		stand_end = 40,
		walk_start = 240,
		walk_end = 280,
		run_start = 91,
		run_end = 108,
		punch_start = 110,
		punch_end = 143,
    dattack_start =180,
    dattack_end=230,
	}
})
-- arrow manticore
lucky_bosses:register_arrow("lucky_bosses:spine", {
	visual = "sprite",
	visual_size = {x = 1, y = 1},
	textures = {"manticore_spine_flying.png"},
	velocity = 10,
	-- direct hit
	hit_player = function(self, player)
		player:punch(self.object, 1.0, {
			full_punch_interval = 1.0,
			damage_groups = {fleshy = 5},
		}, nil)
	end,

	hit_mob = function(self, player)
		player:punch(self.object, 1.0, {
			full_punch_interval = 1.0,
			damage_groups = {fleshy = 4},
		}, nil)
	end,
})


lucky_bosses:register_mob("lucky_bosses:lucky_wizard", {
	type = "monster",
	hp_max = 8330,
	hp_min = 833,
	collisionbox = {-1, 0, -1, 1, 5, 1},
	visual = "mesh",
	mesh = "character.b3d",
	textures = {{"darkwizard.png"}},
	visual_size = {x=1, y=2},
	makes_footstep_sound = true,
	maxus = true,
	view_range = 95,
  rotate = 270,
	walk_velocity = 4,
	run_velocity = 9,
    sounds = {
		shoot_attack = "mesed",
		attack = "mese_dragon",
		distance = 90,
	},
	damage = 186,
	jump = true,
	jump_height = 15,
  putter = true,
	drops = {
		{name = "lucky_drops:staff_magic",
		chance = 1,
		min = 0,
		max = 1},
		{name = "lottweapons:helmet_magic",
		chance = 1,
		min = 0,
		max = 1},
		{name = "lottweapons:chestplate_magic",
		chance = 1,
		min = 0,
		max = 1},
		{name = "lottweapons:leggings_magic",
		chance = 1,
		min = 0,
		max = 1},
		{name = "lottweapons:boots_magic",
		chance = 1,
		min = 0,
		max = 1},
		{name = "lottweapons:shield_magic",
		chance = 1,
		min = 0,
		max = 1},
    },
	armor = 90,
	drawtype = "front",
	water_damage = 0,
	lava_damage = 0,
	light_damage = 0,
	on_rightclick = nil,
	attack_type = "dogshoot",
	dogshoot_stop = true,
	arrow = "lucky_bosses:magicball",
	reach = 5,
	shoot_interval = 0.01,
	shoot_offset = -1,
	animation = {
		speed_normal = 15,
		speed_run = 25,
		stand_start = 60,
		stand_end = 120,
		walk_start = 161,
		walk_end = 205,
		run_start = 206,
		run_end = 242,
		punch_start = 242,
		punch_end = 275,
		punch1_start = 330,
		punch1_end = 370,
    dattack_start = 120,
    dattack_end = 160,
    }
})
lucky_bosses:register_arrow("lucky_bosses:wizardball", {
	visual = "sprite",
	visual_size = {x = 1, y = 1},
	textures = {"transparent.png"},
	velocity = 10,
	remover = true,
	-- direct hit
	hit_player = function(self, player)
		player:punch(self.object, 1.0, {
			full_punch_interval = 1.0,
			damage_groups = {fleshy = 120},
		}, nil)
	end
})
