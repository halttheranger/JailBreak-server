--basic stuff



--TNT
--This does not add the node. Register the node yourself, and have the on_hit to add the entity and remove the node.
--def info (required)
--tdef.radus
--tdef.sound (of the explosion)
--tdef.texture(.top, .bottom, .side)
--tdef.timer
--tdef.damage
--tdef.entityname (this is used to add the entity after hitting the node)
--tdef.entityshortname
--tdef.nodename (for defusing the TNT. this node is added to the hitter's inventory)

--nodedef
--
--name = the node's name
--description = the node's description
--tiles = the images
--tiles.top, tiles. side, tiles.bottom = self explanatory

--entitydef
--name = the entity's name
--tiles = same as nodedef
--radius = the ecplosion radius
--timer = how long till the explosion
function qt.register_tnt(nodedef, entitydef)
	minetest.register_node(nodedef.name, {
		description = nodedef.description,
		tiles = {nodedef.tiles.top, nodedef.tiles.bottom, nodedef.tiles.side},
		is_ground_content = false,
		groups = {crumbly=3,},
		sounds = default.node_sound_dirt_defaults(),
		on_punch = function(pos, node, puncher)
			minetest.remove_node(pos)
			local obj = minetest.add_entity(pos, entitydef.name)
			if obj then
			obj:setacceleration({ x = 0, y = -10, z = 0})
			end
		end,
		on_blast = function(pos, intensity)
			minetest.remove_node(pos)
			local obj =  minetest.add_entity(pos, entitydef.name .."_short")
			if obj then
			obj:setacceleration({ x = 0, y = -10, z = 0})
			end
		end
	})

	minetest.register_entity(entitydef.name, {
		physical = true,
		collisionbox = {-0.5,-0.5,-0.5, 0.5,0.5,0.5},
		visual = "cube",
		textures = {entitydef.tiles.top, entitydef.tiles.bottom,
				entitydef.tiles.side, entitydef.tiles.side,
				entitydef.tiles.side, entitydef.tiles.side},
		timer = 0,
		health = 1,
		radius = entitydef.radius,
		nodename = nodedef.name,
		boom_timer = entitydef.timer,

		on_step = function (self, dtime)
			self.timer = self.timer + dtime
			local tntpos = self.object:getpos()
			local below = {x = tntpos.x, y = tntpos.y-1, z = tntpos.z}
			local node_below = minetest.get_node(below)
			--[[
			if node_below.name == "air" then
				self.object:setvelocity ({ x = 0, y = -10, z = 0})
			end
			--]]
			if self.timer > self.boom_timer then
				qt.explode(tntpos, self.radius)
				self.object:remove()
			end
		end,

		on_punch = function (self, hitter)
			self.object:remove()
			hitter:get_inventory():add_item("main", self.nodename)
		end,
	})


	--tnt entity for tnt activated by nearby explosion
	minetest.register_entity(entitydef.name .."_short", {
		physical = true,
		collisionbox = {-0.5,-0.5,-0.5, 0.5,0.5,0.5},
		visual = "cube",
		textures = {entitydef.tiles.top, entitydef.tiles.bottom,
				entitydef.tiles.side, entitydef.tiles.side,
				entitydef.tiles.side, entitydef.tiles.side},
		timer = 0,
		health = 1,
		radius = entitydef.radius,
		nodename = nodedef.name,
		boom_timer = entitydef.timer/4,

		on_step = function (self, dtime)
			self.timer = self.timer + dtime
			local tntpos = self.object:getpos()
			local below = {x = tntpos.x, y = tntpos.y-1, z = tntpos.z}
			local node_below = minetest.get_node(below)
			--[[
			if node_below.name == "air" then
				self.object:setvelocity ({ x = 0, y = -10, z = 0})
			end
			--]]
			if self.timer > self.boom_timer then
				qt.explode(tntpos,self.radius)
				self.object:remove()
			end
		end,

		on_punch= function (self, hitter)
			self.object:remove()
			hitter:get_inventory():add_item("main", self.nodename)
		end,
	})

end

--some basic shooting functions (these can be used as the sdef.entity_on_hit_entity_function (obj, pos), sdef.entity_on_hit_node_function (nodename, pos, lastpos), and
--sdef,entity_max_fange_function. if those are left nil, these are used)
--note: the register_shooter code automatically removes the shot entity for you

function qt.entity_hit_entity_basic (damage, self, object)
	object:punch(self.object, 1.0, {
						full_punch_interval=1.0,
						damage_groups={fleshy=damage},
					}, nil)
end

function qt.entity_hit_node_basic (last_pos, drop)
	minetest.add_item(last_pos, drop)
end

function qt.entity_max_range_basic ()
end

--register_shooter
--def required info
--
--sdef.shootername
--sdef.is_shooter_tool (boolian val)
--sdef.tool_wear
--sdef.shooter_image
--sdef.shooter_def
--sdef.take_ammo (boolian value)
--sdef.ammo_name (seprately registered item, taken when shot)
--sdef.shoot_sound
--sdef.entity_name
--sdef.entity_image
--sdef.entity_weight
--sdef.entity_min_range
--sdef.entity_max_range
--sdef.damage (how much damage a entity receives if no special function)
--sdef.on_hit_entity (self, obj)  leave blank to punch entity
--sdef.on_hit_node (self, node) leave blank to drop ammo, if any   ---all three of these functions automatically remove arrow
--sdef.on_leave_range (self) leave blank for no action
--sdef.visual

function qt.register_shooter(sdef)
	if sdef.take_ammo == nil then
		sdef.take_ammo = false
	end

	minetest.register_entity(sdef.entity_name, {
		physical = false,
		timer=0,
		visual = sdef.visual,
		visual_size = {x=0.1, y=0.1},
		textures = sdef.entity_image,
		lastpos={},
		collisionbox = {0,0,0,0,0,0},
		hit_node = sdef.on_hit_node,
		hit_entity = sdef.on_hit_entity,
		leave_range = sdef.on_leave_range,
		drop = sdef.ammo_name,
		damage = sdef.damage,
		max_range = sdef.entity_max_range,
		take_ammo = sdef.take_ammo,

		on_step = function(self, dtime)
			self.timer=self.timer+dtime
			local pos = self.object:getpos()
			local node = minetest.env:get_node(pos)
			--hit an entity
			if self.timer>sdef.entity_min_range then
				local objs = minetest.env:get_objects_inside_radius({x=pos.x,y=pos.y,z=pos.z}, 2)
				for k, obj in pairs(objs) do
					if obj:get_luaentity() ~= nil then
						if obj:get_luaentity().name ~= sdef.entity_name and obj:get_luaentity().name ~= "__builtin:item" then
							if self.hit_entity ~= nil then
								self.hit_entity (self, obj)
							else
								qt.entity_hit_entity_basic (self.damage, self, obj)
							end
							self.object:remove()
						end
					end
				end
			end
			--hit a node
			if self.lastpos.x~=nil then
				if node.name ~= "air" then
					if self.hit_node ~= nil then
						self.hit_node (self, node)
					elseif sdef.ammo_name ~= nil then
						qt.entity_hit_node_basic (self.lastpos, self.drop)
					end
					self.object:remove()
				end
			end
			--go out of bounds
			if sdef.entity_max_range ~= nil then
				if self.timer> sdef.entity_max_range then
					if self.leave_range ~= nil then
						self.leave_range (self)
					else
						qt.entity_max_range_basic ()
					end
					self.object:remove()
				end
			end
			self.lastpos={x=pos.x, y=pos.y, z=pos.z}
		end,
	})

	--the tool/craftitem
	if sdef.is_shooter_tool == true then

		minetest.register_tool(sdef.shootername, {
			description = sdef.shooter_def,
			inventory_image = sdef.shooter_image,
			on_use = function (itemstack, user, pointed_thing)
				if sdef.take_ammo == true then
					if not minetest.setting_getbool("creative_mode") then
						if user:get_inventory():remove_item("main", sdef.ammo_name) ~= "" then
							itemstack:add_wear(65535/sdef.tool_wear)
							qt.shoot_entity (user, sdef.entity_name)
							if sdef.shoot_sound ~= nil then
								minetest.sound_play(sdef.shoot_sound, {pos=playerpos})
							end
						end
					else
						qt.shoot_entity (user, sdef.entity_name)
						if sdef.shoot_sound ~= nil then
							minetest.sound_play(sdef.shoot_sound, {pos=playerpos})
						end
					end
				else
					 qt.shoot_entity (user, sdef.entity_name)
					 if sdef.shoot_sound ~= nil then
						minetest.sound_play(sdef.shoot_sound, {pos=playerpos})
					end
				end
				return itemstack
			end,
		})

	else

		minetest.register_craftitem(sdef.shootername, {
			description = sdef.shooter_def,
			inventory_image = sdef.shooter_image,
			on_use = function (itemstack, user, pointed_thing)
				if sdef.take_ammo == true then
					if not minetest.setting_getbool("creative_mode") then
						if user:get_inventory():remove_item("main", sdef.ammo_name) ~= "" then
							qt.shoot_entity (user, sdef.entity_name)
							if sdef.shoot_sound ~= nil then
								minetest.sound_play(sdef.shoot_sound, {pos=playerpos})
							end
						end
					else
						qt.shoot_entity (user, sdef.entity_name)
						if sdef.shoot_sound ~= nil then
							minetest.sound_play(sdef.shoot_sound, {pos=playerpos})
						end
					end
				else
					 qt.shoot_entity (user, sdef.entity_name)
					 if sdef.shoot_sound ~= nil then
						minetest.sound_play(sdef.shoot_sound, {pos=playerpos})
					end
				end
				return itemstack
			end,
		})
	end
end


function qt.shoot_entity (player, entityname)
	local playerpos = player:getpos()
	local obj = minetest.env:add_entity({x=playerpos.x,y=playerpos.y+1.5,z=playerpos.z}, entityname)
	local dir = player:get_look_dir()
	obj:setvelocity({x=dir.x*19, y=dir.y*19, z=dir.z*19})
	obj:setacceleration({x=dir.x*-3, y=-10, z=dir.z*-3})
	obj:setyaw(player:get_look_yaw()+math.pi)
end
