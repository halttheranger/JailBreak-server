--[[
def_table consists of:

description
tiles{"inventory", "source_animated", "flowing_animated", "bucket"}
alpha
drowning
viscosity
renewable
range
damage_ber_second
post_effect_color  --{a=120, r=30, g=60, b=90}
custom_groups        --{ "liquidtype"=3, liquid=3, ?puts_out_fire=3}
custom_groups_flowing --{ "liquidtype"=3, liquid=3, ?puts_out_fire=3, not_in_creative_inventory=1}

--]]

qt.register_liquid = function(name, def_table)
minetest.register_node(":"..name.."_source", {
	description = def_table.description.." Source",
	inventory_image = minetest.inventorycube(def_table.tiles.inventory),
	drawtype = "liquid",
	tiles = {
		{
			name = def_table.tiles.source_animated,
			animation = {
				type = "vertical_frames",
				aspect_w = 16,
				aspect_h = 16,
				length = 2.0,
			},
		},
	},
	special_tiles = {
		-- New-style water source material (mostly unused)
		{
			name = def_table.tiles.source_animated,
			animation = {
				type = "vertical_frames",
				aspect_w = 16,
				aspect_h = 16,
				length = 2.0,
			},id,
			backface_culling = false,
		},
	},
	alpha = def_table.alpha,
	paramtype = "light",
	walkable = false,
	pointable = false,
	diggable = false,
	buildable_to = true,
	is_ground_content = false,
	drop = "",
	drowning = def_table.drowning,
	liquidtype = "source",
	liquid_alternative_flowing = name.."_flowing",
	liquid_alternative_source = name.."_source",
	liquid_viscosity = def_table.viscosity,
	liquid_renewable = def_table.renewable,
	liquid_range = def_table.range,
	damage_per_second = def_table.damage_per_second,
	post_effect_color = def_table.post_effect_color,
	groups = def_table.custom_groups,
	on_blast = function(pos, intensity)
		--this is blank, so obsidian will not be destroyed
	end,
})

minetest.register_node(":"..name.."_flowing", {
	description = def_table.description.." Flowing",
	inventory_image = minetest.inventorycube(def_table.tiles.inventory),
	drawtype = "flowingliquid",
	tiles = {def_table.tiles.inventory},
	special_tiles = {
		{
			name = def_table.tiles.flowing_animated,
			backface_culling = false,
			animation = {
				type = "vertical_frames",
				aspect_w = 16,
				aspect_h = 16,
				length = 0.8,
			},
		},
		{
			name = def_table.tiles.flowing_animated,
			backface_culling = true,
			animation = {
				type = "vertical_frames",
				aspect_w = 16,
				aspect_h = 16,
				length = 0.8,
			},
		},
	},
	alpha = def_table.alpha,
	paramtype = "light",
	paramtype2 = "flowingliquid",
	walkable = false,
	pointable = false,
	diggable = false,
	buildable_to = true,
	is_ground_content = false,
	drop = "",
	drowning = def_table.drowning,
	liquidtype = "flowing",
	liquid_alternative_flowing = name.."_flowing",
	liquid_alternative_source = name.."_source",
	liquid_viscosity = def_table.viscosity,
	liquid_renewable = def_table.renewable,
	liquid_range = def_table.range,
	damage_per_second = def_table.damage_per_second,
	post_effect_color = def_table.post_effect_color,
	groups = def_table.custom_groups_flowing,
	on_blast = function(pos, intensity)
		--this is blank, so obsidian will not be destroyed
	end,
})

bucket.register_liquid(
	name.."_source",
	name.."_flowing",
	":"..name.."_bucket",
	def_table.tiles.bucket,
	def_table.description.." Bucket"
)

minetest.register_alias(":"..name.."_bucket", name.."_bucket")

end

qt.register_liquid("qt:yellow_slime", {
description = "Yellow Slime",
tiles = {inventory = "yellow_slime.png", source_animated="yellow_slime_animated_source.png", flowing_animated="yellow_slime_animated_flowing.png", bucket="bucket_yellow_slime.png"},
alpha = 200,
drowning = 1,
viscosity = 3,
renewable = false,
range = 3,
damage_ber_second = 10,
post_effect_color = {a=200, r=255, g=240, b=0},
custom_groups = {slime=3, yellow_slime=3, liquid=3, puts_out_fire=3, not_in_creative_inventory=0},
custom_groups_flowing = {slime=3, yellow_slime=3, liquid=3, puts_out_fire=3, not_in_creative_inventory=1},
})


minetest.register_abm({
	nodenames = {"group:yellow_slime"},
	neighbors = {"group:water"},
	interval = 1,
	chance = 2,
	action = function(pos)
		qt.explode(pos, 3)
	end,
})

minetest.register_node(":qt:sponge", {
	description = "Sponge",
	tiles = {"sponge.png"},
	groups = {sponge=1, oddly_breakable_by_hand=3,flammable=2},
	liquids_pointable = true,
	--sounds = default.node_sound_stone_defaults(),
	on_use = function (itemstack, user, pointed_thing)
		if pointed_thing.under ~= nil then
		local node = minetest.get_node(pointed_thing.under)
		local group = minetest.get_node_group(node.name, "liquid")
		if group and group ~= 0 then
				minetest.remove_node(pointed_thing.under)
		end
		end
	end,
})

minetest.register_abm({
	nodenames = {"group:yellow_slime"},
	neighbors = {"group:lava"},
	interval = 1,
	chance = 2,
	action = function(...)
		cool_yellow_slime(...)
	end,
})

cool_yellow_slime = function(pos)
	minetest.set_node(pos, {name = "qt:sponge"})
	minetest.sound_play("default_cool_lava",
		{pos = pos, max_hear_distance = 16, gain = 0.25})
end


minetest.register_tool("qt:extracter", {
	description = "Extracter",
	inventory_image = "extracter.png",
	liquids_pointable = true,
	on_use = function (itemstack, user, pointed_thing)
		if pointed_thing.under ~= nil then
		local node = minetest.get_node(pointed_thing.under)
		local group = minetest.get_node_group(node.name, "poison_plant")
		local lgroup = minetest.get_node_group(node.name, "liquid")
		if group and group ~= 0 then
			--minetest.debug("error 1")
			itemstack:add_wear(65535/1000)
			--minetest.debug("error 2")
			local num = math.random(2, 5)
			if num == 0 then
			 num =2
			end
			minetest.add_item(pointed_thing.under, "qt:poison_droplet "..num)
			--minetest.debug("nope :/")
		elseif lgroup and lgroup ~= 0 then
			local liquidsource = minetest.registered_nodes[node.name].liquid_alternative_source
			if liquidsource and node.name == liquidsource then
				minetest.add_item(pointed_thing.under, liquidsource)
			end
		end

		return itemstack
		end
	end,
})
