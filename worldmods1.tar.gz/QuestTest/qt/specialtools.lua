minetest.register_tool("qt:wand_blue_gem", {
	description = "Sapphire Wand",
	inventory_image = "blue_gem_wand.png",
	on_use = function (itemstack, user, pointed_thing)
		if pointed_thing.under ~= nil then
			local node_dat = minetest.registered_nodes[minetest.get_node(pointed_thing.under).name]
			if node_dat.groups.antimagic == nil then
				minetest.set_node({x=pointed_thing.under.x, y=pointed_thing.under.y, z=pointed_thing.under.z}, {name="default:water_source"})
				itemstack:add_wear(65535/15000)
			end
			return itemstack
		end
	end,
	on_place = function (itemstack, user, pointed_thing)
		if pointed_thing.above ~= nil then
			minetest.set_node({x=pointed_thing.above.x, y=pointed_thing.above.y, z=pointed_thing.above.z}, {name="default:water_source"})
			itemstack:add_wear(65535/15000)
			return itemstack
		end
	end,
})

minetest.register_craft({
	output = 'qt:wand_blue_gem',
	recipe = {
		{'qt:gem_blue'},
		{'qt_gold:gold_stick'},
		{'qt_gold:gold_stick'},
	}
})

minetest.register_alias("qt:wand_blue_gem_replacer", "qt:wand_blue_gem")

minetest.register_tool("qt:wand_red_gem", {
	description = "Ruby Wand",
	inventory_image = "red_gem_wand.png",
	on_use = function (itemstack, user, pointed_thing)
		if pointed_thing.under ~= nil then
			local node_dat = minetest.registered_nodes[minetest.get_node(pointed_thing.under).name]
			if node_dat.groups.antimagic == nil then
				minetest.set_node({x=pointed_thing.under.x, y=pointed_thing.under.y, z=pointed_thing.under.z}, {name="default:lava_source"})
				itemstack:add_wear(65535/15000)
			end
			return itemstack
		end
	end,
	on_place = function (itemstack, user, pointed_thing)
		if pointed_thing.above ~= nil then
			minetest.set_node({x=pointed_thing.above.x, y=pointed_thing.above.y, z=pointed_thing.above.z}, {name="default:lava_source"})
			itemstack:add_wear(65535/15000)
			return itemstack
		end
	end,
})

minetest.register_craft({
	output = 'qt:wand_red_gem',
	recipe = {
		{'qt:gem_red'},
		{'qt_gold:gold_stick'},
		{'qt_gold:gold_stick'},
	}
})

minetest.register_alias("qt:wand_red_gem_replacer", "qt:wand_red_gem")

local function remove_stone (pos)
local newpos = { x = pos.x-1, y = pos.y-1, z = pos.z-1}
	for xa = 0, 2, 1 do
	for ya = 0, 2, 1 do
	for za = 0, 2, 1 do
		local inpos = {x = newpos.x + xa, y = newpos.y + ya, z = newpos.z + za}
		local node = minetest.env:get_node(inpos)
		if node.name == "default:stone" then
			minetest.remove_node(inpos)
		end
	end
	end
	end
end

minetest.register_tool("qt:wand_sky_blue_gem", {
	description = "Aqumarine Wand",
	inventory_image = "sky_blue_gem_wand.png",
	on_use = function (itemstack, user, pointed_thing)
		if pointed_thing.under ~= nil then
			remove_stone (pointed_thing.under)
			itemstack:add_wear(65535/15000)
			return itemstack
		end
	end
})

minetest.register_craft({
	output = 'qt:wand_sky_blue_gem',
	recipe = {
		{'qt:gem_sky_blue'},
		{'qt_gold:gold_stick'},
		{'qt_gold:gold_stick'},
	}
})

minetest.register_tool("qt:wand_green_gem", {
	description = "Emerald Wand",
	inventory_image = "green_gem_wand.png",
	on_use = function (itemstack, user, pointed_thing)
		if pointed_thing.above ~= nil then
			default.grow_tree(pointed_thing.above, 2 == 1)
			itemstack:add_wear(65535/15000)
			return itemstack
		end
	end
})

minetest.register_craft({
	output = 'qt:wand_green_gem',
	recipe = {
		{'qt:gem_green'},
		{'qt_gold:gold_stick'},
		{'qt_gold:gold_stick'},
	}
})



minetest.register_tool("qt:disrupter", {
	description = "Node Disrupter",
	inventory_image = "disrupter.png",
	on_use = function (itemstack, user, pointed_thing)
		if pointed_thing.under ~= nil then
			local node = minetest.env:get_node(pointed_thing.under)
			local nodedat = minetest.registered_nodes[node.name]
			if nodedat.groups.undisruptable ~= nil or nodedat.diggable == false then
				--
			else
				itemstack:add_wear(65535/15000)
				if nodedat.on_disrupt == nil then
					minetest.remove_node(pointed_thing.under)
					minetest.add_item(pointed_thing.under, node.name)
				else
					itemstack = nodedat.on_disrupt(itemstack, user, pointed_thing)
				end
			end

			return itemstack
		end
	end
})


--on_disrupt callbacks: (itemstack, disrupter, pointed_thing)
--return itemstack (note: wear is auto-handled)


minetest.register_craft({
	output = 'qt:disrupter',
	recipe = {
		{'default:steel_ingot', 'default:obsidian_shard', 'default:steel_ingot'},
		{'', 'default:steel_ingot', ''},
		{'', 'default:steel_ingot', ''},
	}
})

--[[
minetest.register_node("qt:undisruptable", {
	description = "disruptable Block",
	tiles = {"corilium_block.png"},
	is_ground_content = true,
	groups = {cracky=1,level=3},
	sounds = default.node_sound_stone_defaults(),
	--diggable = false,
	on_disrupt = function(itemstack, disrupter, pointed_thing)
		minetest.set_node(pointed_thing.under, {name = "default:diamondblock"})
	end,
})
--]]

minetest.register_tool("qt:copper_fist", {
	description = "Copper Fist",
	inventory_image = "copper_fist.png",
	tool_capabilities = {
		full_punch_interval = 1.0,
		max_drop_level=1,
		groupcaps={
			snappy={times={[1]=2.5, [2]=1.20, [3]=0.35}, uses=25, maxlevel=2},
		},
		damage_groups = {fleshy=5},
	}
})

minetest.register_craft({
	output = 'qt:copper_fist',
	recipe = {
		{'default:copper_ingot', 'default:copper_ingot', 'default:copper_ingot'},
		{'default:copper_ingot', '', ''},
		{'default:copper_ingot', 'default:copper_ingot', 'default:copper_ingot'},
	}
})

minetest.register_tool("qt:copper_staff", {
	description = "Copper Staff",
	inventory_image = "copper_staff.png",
	tool_capabilities = {
		full_punch_interval = 0.5,
		max_drop_level=1,
		groupcaps={
			snappy={times={[1]=2.5, [2]=1.20, [3]=0.35}, uses=35, maxlevel=2},
		},
		damage_groups = {fleshy=7},
	}
})

minetest.register_craft({
	output = 'qt:copper_staff',
	recipe = {
		{'', '', 'default:copperblock'},
		{'', 'default:copperblock', ''},
		{'default:copperblock', '', ''},
	}
})

--[[
tool to test the qt:get_nodes_in_radius and qt.get_nodes_on_radius functions

minetest.register_tool("qt:sphere", {
	description = "Sphere Test Thing",
	inventory_image = "disrupter.png",
	on_use = function (itemstack, user, pointed_thing)
		local nodetable = qt.get_nodes_on_radius(pointed_thing.under, 5)
		for _, nodedat in ipairs(nodetable) do
			if nodedat.noderef.name == "air" then
				minetest.set_node(nodedat.pos, {name = "default:glass"})
			end
		end
	end
})
--]]
