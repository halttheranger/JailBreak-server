--rgen functions (seperate api by fessmk)
rgen = {}
rgen.data = {}

rgen.register_random_data = function(box, data)
	if rgen.data[box] ~= nil then
		local number = rgen.data[box].number
		number = number+1
		rgen.data[box][number] = data
		rgen.data[box].number = number
	else
		rgen.data[box] = {}
		rgen.data[box].number = 1
		rgen.data[box][1] = data
	end
end

rgen.get_random_data = function(box)
	if rgen.data[box] ~= nil then
		local dispose = math.random(1, 30) --some thing used to dispose of the 1st "random" number.
		local rnumber = math.random(rgen.data[box].number)
		if rgen.data[box][rnumber] ~= nil then
			return rgen.data[box][rnumber]
		else
			return nil
		end
	else
		return nil
	end
end

rgen.set_randomseed = function(seed)
	math.randomseed(seed)
	rgen.randomseed = seed
end


--dimention functions

rgen.register_random_data("Miner_l1", "default:stone")
rgen.register_random_data("Miner_l1", "default:stone_with_coal")
rgen.register_random_data("Miner_l1", "default:stone_with_iron")
rgen.register_random_data("Miner_l1", "default:stone_with_copper")
rgen.register_random_data("Miner_l1", "default:stone_with_gold")
rgen.register_random_data("Miner_l1", "qt:stone_with_farmite")
rgen.register_random_data("Miner_l1", "qt:stone_with_olmite")
rgen.register_random_data("Miner_l1", "qt:glowstone")

rgen.register_random_data("Miner_l2","default:stone_with_mese")
rgen.register_random_data("Miner_l2","default:stone_with_diamond")
rgen.register_random_data("Miner_l2","qt:stone_with_blue_gem")
rgen.register_random_data("Miner_l2","qt:stone_with_green_gem")
rgen.register_random_data("Miner_l2","qt:stone_with_red_gem")
rgen.register_random_data("Miner_l2","qt:stone_with_sky_blue_gem")
rgen.register_random_data("Miner_l2","qt:jade_ore")

if minetest.get_modpath("technic") ~= nil then
	rgen.register_random_data("Miner_l2","technic:mineral_uranium")
	rgen.register_random_data("Miner_l1","technic:mineral_chromium")
	rgen.register_random_data("Miner_l1","technic:mineral_zinc")
	rgen.register_random_data("Miner_l1","technic:mineral_lead")
	rgen.register_random_data("Miner_l1","technic:mineral_sulfur")
	--rgen.register_random_data("Miner_l1","technic:granite")
	--rgen.register_random_data("Miner_l1","technic:marble")
	--granite and marble are disabled
end
if minetest.get_modpath("moreores") ~= nil then
	rgen.register_random_data("Miner_l1","moreores:mineral_tin")
	rgen.register_random_data("Miner_l1","moreores:mineral_silver")
	rgen.register_random_data("Miner_l2","moreores:mineral_mithril")
end
--rgen.register_random_data("Miner_l1","")
--rgen.register_random_data("Miner_l2","technic:")



--minetest.get_content_id(
--[[
stone_with_coal
stone_with_iron
stone_with_copper
stone_with_gold

stone_with_mese
stone_with_diamond
stone_with_blue_gem
stone_with_green_gem
stone_with_red_gem
stone_with_sky_blue_gem

stone_with_farmite
stone_with_olmite
--]]
