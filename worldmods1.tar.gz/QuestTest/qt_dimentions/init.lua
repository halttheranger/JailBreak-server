dofile(minetest.get_modpath("qt_dimentions").."/functions.lua")
dofile(minetest.get_modpath("qt_dimentions").."/nodes.lua")
dofile(minetest.get_modpath("qt_dimentions").."/portals.lua")



    minetest.register_on_generated(function(minp, maxp, seed)
            local t1 = os.clock()
            local vm, emin, emax = minetest.get_mapgen_object("voxelmanip")
            local a = VoxelArea:new{
                    MinEdge={x=emin.x, y=emin.y, z=emin.z},
                    MaxEdge={x=emax.x, y=emax.y, z=emax.z},
            }

            local data = vm:get_data()

            local c_dirt  = minetest.get_content_id("default:dirt")
            local c_grass = minetest.get_content_id("default:dirt_with_grass")
            local c_water = minetest.get_content_id("default:water_source")
			local c_lava = minetest.get_content_id("default:lava_source")
			local c_stone = minetest.get_content_id("default:stone")
			local c_air = minetest.get_content_id("air")

			local c_bedrock = minetest.get_content_id("qt:dimentional_seperator_203948")

			local c_nether_stone = minetest.get_content_id("qt:nether_stone")
			local c_nether_sand = minetest.get_content_id("qt:nether_sand")

			local c_poison_stone = minetest.get_content_id("qt:poison_stone")
			local c_poison_dirt = minetest.get_content_id("qt:poison_dirt")
			local c_poison_grass = minetest.get_content_id("qt:poison_dirt_with_grass")
			local c_poison_liquid = minetest.get_content_id("qt:poison_liquid_source")


            local sidelen = maxp.x - minp.x + 1

            local nethernoise = minetest.get_perlin_map(
                    {offset=-12, scale=1, spread={x=200, y=50, z=200}, seed=50, octaves=5, persist=0.6},
                    {x=sidelen, y=sidelen, z=sidelen}
            )
            local nethernvals = nethernoise:get3dMap_flat({x=minp.x, y=minp.y, z=minp.z})

            local ni = 1
            for z = minp.z, maxp.z do
            for y = minp.y, maxp.y do
            for x = minp.x, maxp.x do
					if y <= -600 and y >= -610 then
							local vi = a:index(x, y, z)
							data[vi] = c_bedrock
					end
					--nether
					if  y <= -611 and y >= -800 then
							local vi = a:index(x, y, z)
							data[vi] = c_air
							if nethernvals[ni] - (y - 25) / 55 > 0.5 then
									local vi = a:index(x, y, z)
									local va = a:index(x, y-1, z)
									local vb = a:index(x, y-2, z)
									local vc = a:index(x, y-3, z)
									if y < 679 then
											data[vi] = c_nether_sand
											data[va] = c_nether_sand
											data[vb] = c_nether_sand
											data[vc] = c_nether_stone
									else
											data[vi] = c_nether_sand
											data[va] = c_nether_sand
											data[vb] = c_nether_sand
											data[vc] = c_nether_stone
									end
							elseif y < -680 then
									local vi = a:index(x, y, z)
									data[vi] = c_lava
							end
					end
					if y <= -801 and y >= -810 then
						local vi = a:index(x, y, z)
						data[vi] = c_bedrock
					end
					--miner's dimention
					if y <= -811 and y >= -830 then
						local vi = a:index(x, y, z)
						data[vi] = c_air
					end
					if y <= -831 and y >= -850 then
						local vi = a:index(x, y, z)

						--rgen.set_randomseed(x*y*z)
						local name = rgen.get_random_data("Miner_l1")
						local cdat = minetest.get_content_id(name)
						data[vi] = cdat
					end
					if y <= -851 and y >= -880 then
						local vi = a:index(x, y, z)
						--rgen.set_randomseed(x*y*z)
						local name = rgen.get_random_data("Miner_l2")
						local cdat = minetest.get_content_id(name)
						data[vi] = cdat
					end

					if y <= -881 and y >= -890 then
						local vi = a:index(x, y, z)
						data[vi] = c_bedrock
					end

					--poison

					if y <= -891 and y >= -939 then
						local vi = a:index(x, y, z)
						data[vi] = c_air
					end


					if y <= -940 and y >= -941 then
						local vi = a:index(x, y, z)
						local vb = a:index(x, y-1, z)
						if y == -940 then
							if rgen.get_random_data("P_is_plant") == true then --get if the node should be a plant, 4 out of 7 chance
								local name = rgen.get_random_data("P_plants") --gets a random plant
								local cdat = minetest.get_content_id(name)
								data[vi] = cdat --sets the plant
								data[vb] = c_poison_grass --changes the node under the plant from poison liquid to poison dirt with grass
							else
								data[vi] = c_air --if not a plant, makes the node air
							end
						else
							data[vi] = c_poison_liquid --make the poison liquid base. this will change to dirt with grass if a plant spawns above
						end
					end

					if y <= -942 and y >= -944 then
						local vi = a:index(x, y, z)
						data[vi] = c_poison_dirt
					end

					if y <= -945 and y >= -980 then
						local vi = a:index(x, y, z)
						data[vi] = c_poison_stone
					end

					if y <= -981 and y >= -990 then
						local vi = a:index(x, y, z)
						data[vi] = c_bedrock
					end

					--
                    ni = ni + 1
            end
            end
            end

            vm:set_data(data)

            vm:calc_lighting(
                    {x=minp.x-16, y=minp.y, z=minp.z-16},
                    {x=maxp.x+16, y=maxp.y, z=maxp.z+16}
            )
            vm:write_to_map(data)
    end)

