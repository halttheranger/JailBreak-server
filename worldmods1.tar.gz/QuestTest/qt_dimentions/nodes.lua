minetest.register_node(":qt:dimentional_seperator_203948", {
	description = "Dimentional Seperator - If this is in your inventory, then deleate it!",
	tiles = {"dimentional_seperator.png"},
	groups = {
		dimentional_seperator = 1,
		not_in_creative_inventory = 1
	},
	sounds = nil,
	pointable = false,
	buildable_to = false,
	diggable = false,
	damage_per_second = 100,
	on_blast = function(pos, intensity)
		--this is blank, so obsidian will not be destroyed
	end,
})

minetest.register_node(":qt:nether_stone", {
	description = "Nether Stone",
	tiles = {"nether_stone.png"},
	is_ground_content = true,
	groups = {cracky=3, stone=1, nether=1},
	sounds = default.node_sound_stone_defaults(),
	light_source = 7,
})

minetest.register_craft({
	type = "fuel",
	recipe = "qt:nether_stone",
	burntime = 555,
})

minetest.register_node(":qt:nether_sand", {
	description = "Nether Sand",
	tiles = {"nether_sand.png"},
	is_ground_content = true,
	groups = {crumbly=3, falling_node=1, sand=1, nether=1},
	sounds = default.node_sound_sand_defaults(),
	light_source = 5,
	drop = {
		max_items = 1,
		items = {
			{
				items = {'qt:fireflower_seeds'},
				rarity = 20,
			},
			{
				items = {'qt:nether_sand'},
			}
		}
	},
})

minetest.register_craft({
	type = "fuel",
	recipe = "qt:nether_sand",
	burntime = 370,
})

local growtime = 45

minetest.register_craftitem(":qt:fireflower_seeds", {
	description = "Fireflower Seeds",
	inventory_image = "fireflower_seeds.png",
	on_place = function(itemstack, placer, pointed_thing)
		if minetest.get_node(pointed_thing.under).name == "qt:nether_sand" then
			minetest.env:set_node(pointed_thing.above, {name=":qt:fireflower_plant_1"})
			itemstack:take_item(1)
			local pos = pointed_thing.above
			minetest.after(growtime, function(pos)
				minetest.env:set_node(pos, {name="qt:fireflower_plant_2"})
			end, pos)
			minetest.after(growtime*2, function(pos)
				minetest.env:set_node(pos, {name="qt:fireflower_plant_3"})
			end, pos)
			return itemstack
		end
	end
})

minetest.register_craftitem(":qt:fireflower", {
	description = "Fireflower",
	inventory_image = "fireflower.png",
})

minetest.register_node(":qt:fireflower_plant_1", {
	description = "Fireflower Plant 1(You Hacker You!)",
	drawtype = "plantlike",
	waving = 1,
	visual_scale = 1,
	tiles = {"fireflower_1.png"},
	inventory_image = "fireflower_1.png",
	wield_image = "fireflower_1.png",
	paramtype = "light",
	walkable = false,
	buildable_to = true,
	is_ground_content = false,
	groups = {snappy=3,flora=1,attached_node=1,not_in_creative_inventory=1},
	sounds = default.node_sound_leaves_defaults(),
	selection_box = {
		type = "fixed",
		fixed = {-0.5, -0.5, -0.5, 0.5, 0, 0.5},
	},
	drop = {"qt:fireflower_seeds"}
})

minetest.register_node(":qt:fireflower_plant_2", {
	description = "Fireflower Plant 2(You Hacker You!)",
	drawtype = "plantlike",
	waving = 1,
	visual_scale = 1,
	tiles = {"fireflower_2.png"},
	inventory_image = "fireflower_2.png",
	wield_image = "fireflower_2.png",
	paramtype = "light",
	walkable = false,
	buildable_to = true,
	is_ground_content = false,
	groups = {snappy=3,flora=1,attached_node=1,not_in_creative_inventory=1},
	sounds = default.node_sound_leaves_defaults(),
	selection_box = {
		type = "fixed",
		fixed = {-0.5, -0.5, -0.5, 0.5, 0, 0.5},
	},
	drop = {"qt:fireflower_seeds"}
})

minetest.register_node(":qt:fireflower_plant_3", {
	description = "Fireflower Plant 3(You Hacker You!)",
	drawtype = "plantlike",
	waving = 1,
	visual_scale = 1,
	tiles = {"fireflower_3.png"},
	inventory_image = "fireflower_3.png",
	wield_image = "fireflower_3.png",
	paramtype = "light",
	walkable = false,
	buildable_to = true,
	is_ground_content = false,
	groups = {snappy=3,flora=1,attached_node=1,not_in_creative_inventory=1},
	sounds = default.node_sound_leaves_defaults(),
	selection_box = {
		type = "fixed",
		fixed = {-0.5, -0.5, -0.5, 0.5, 0, 0.5},
	},
	drop = {
		max_items = 5,
		items = {
			{
				items = {'qt:fireflower_seeds 3'},
			},
			{
				items = {'qt:fireflower'},
			},
			{
				items = {'qt:fireflower'},
				rarity = 10
			}
		}
	},
})

minetest.register_node(":qt:nether_glass", {
	description = "Nether Glass",
	drawtype = "glasslike",
	tiles = {"nether_glass.png"},
	paramtype = "light",
	is_ground_content = false,
	sunlight_propagates = true,
	sounds = default.node_sound_glass_defaults(),
	groups = {cracky=3,oddly_breakable_by_hand=3},
})


minetest.register_craft({
	type = "cooking",
	output = "qt:nether_glass",
	recipe = "qt:nether_sand",
})

minetest.register_node(":qt:jade_ore", {
	description = "Jade Ore",
	tiles = {"default_stone.png^jade_ore.png"},
	groups = {cracky=3},
	sounds = default_stone_sounds,
	drop = "qt:jade"
})

minetest.register_craftitem(":qt:jade", {
	description = "Jade Lump",
	inventory_image = "jade.png",
})

minetest.register_node(":qt:jade_block", {
	description = "Jade Block",
	tiles = {"jade_block.png"},
	is_ground_content = false,
	groups = {cracky=1,},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_craft({
	output = 'qt:jade_block',
	recipe = {
		{'qt:jade', 'qt:jade', 'qt:jade'},
		{'qt:jade', 'qt:jade', 'qt:jade'},
		{'qt:jade', 'qt:jade', 'qt:jade'},
	}
})

minetest.register_craft({
	output = 'qt:jade 9',
	recipe = {
		{'qt:jade_block'},
	}
})


--poison nodes
--[[
minetest.register_node(":qt:poison_", {
	description = "",
	drawtype = "plantlike",
	waving = 1,
	tiles = {".png"},
	inventory_image = ".png",
	wield_image = ".png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	buildable_to = true,
	groups = {snappy=3,flammable=2,flora=1,attached_node=1},
	sounds = default.node_sound_leaves_defaults(),
	selection_box = {
		type = "fixed",
		fixed = {-0.5, -0.5, -0.5, 0.5, -5/16, 0.5},
	},
})
--]]
minetest.register_node(":qt:poison_reeds", {
	description = "Poison Reeds",
	drawtype = "plantlike",
	tiles = {"reeds.png"},
	inventory_image = "reeds.png",
	wield_image = "reeds.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	selection_box = {
		type = "fixed",
		fixed = {-0.3, -0.5, -0.3, 0.3, 0.5, 0.3}
	},
	groups = {snappy=3,flammable=2, poison_plant=1},
	sounds = default.node_sound_leaves_defaults(),

	after_dig_node = function(pos, node, metadata, digger)
		default.dig_up(pos, node, digger)
	end,
})

--grass

minetest.register_node(":qt:poison_grass1", {
	description = "Poison Grass",
	drawtype = "plantlike",
	waving = 1,
	tiles = {"grass1.png"},
	inventory_image = "grass3.png",
	wield_image = "grass3.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	buildable_to = true,
	groups = {snappy=3,flora=1,attached_node=1, poison_plant=1},
	sounds = default.node_sound_leaves_defaults(),
	selection_box = {
		type = "fixed",
		fixed = {-0.5, -0.5, -0.5, 0.5, -5/16, 0.5},
	},
	on_place = function(itemstack, placer, pointed_thing)
		-- place a random node
		local node = rgen.get_random_data("P_grass")
		minetest.set_node(pointed_thing.above, {name = node})
		if not minetest.setting_getbool("creative_mode") then itemstack:take_item() end
		return itemstack
	end,
})

rgen.register_random_data("P_grass", "qt:poison_grass1")
rgen.register_random_data("P_grass", "qt:poison_grass2")
rgen.register_random_data("P_grass", "qt:poison_grass3")

for i = 2, 3 do
minetest.register_node(":qt:poison_grass"..i, {
	description = "Poison Grass",
	drawtype = "plantlike",
	waving = 1,
	tiles = {"grass"..i..".png"},
	inventory_image = "grass"..i..".png",
	wield_image = "grass"..i..".png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	buildable_to = true,
	groups = {snappy=3,flora=1,attached_node=1,not_in_creative_inventory=1, poison_plant=1},
	sounds = default.node_sound_leaves_defaults(),
	drop = "qt:poison_grass1",
	selection_box = {
		type = "fixed",
		fixed = {-0.5, -0.5, -0.5, 0.5, -5/16, 0.5},
	},
})
end

--bushes

minetest.register_node(":qt:poison_bush1", {
	description = "Poison Bush",
	drawtype = "plantlike",
	waving = 1,
	tiles = {"bush1.png"},
	inventory_image = "bush1.png",
	wield_image = "bush1.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	buildable_to = true,
	groups = {snappy=3,flora=1,attached_node=1, poison_plant=1},
	sounds = default.node_sound_leaves_defaults(),
	selection_box = {
		type = "fixed",
		fixed = {-0.5, -0.5, -0.5, 0.5, -5/16, 0.5},
	},
	on_place = function(itemstack, placer, pointed_thing)
		--minetest.debug("runs function")
		local node = rgen.get_random_data("P_bush")
		--minetest.debug("gets random data")
		minetest.set_node({x=pointed_thing.above.x, y=pointed_thing.above.y, z=pointed_thing.above.z, }, {name = node})
		--minetest.debug("places node")
		if not minetest.setting_getbool("creative_mode") then itemstack:take_item() end
		--minetest.debug("takes item")
		return itemstack
	end,
})

rgen.register_random_data("P_bush", "qt:poison_bush1")
rgen.register_random_data("P_bush", "qt:poison_bush2")
rgen.register_random_data("P_bush", "qt:poison_bush3")
rgen.register_random_data("P_bush", "qt:poison_bush4")
rgen.register_random_data("P_bush", "qt:poison_bush5")
rgen.register_random_data("P_bush", "qt:poison_bush6")

for i = 2, 6 do
minetest.register_node(":qt:poison_bush"..i, {
	description = "Poison Bush",
	drawtype = "plantlike",
	waving = 1,
	tiles = {"bush"..i..".png"},
	inventory_image = "bush"..i..".png",
	wield_image = "bush"..i..".png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	buildable_to = true,
	groups = {snappy=3,flora=1,attached_node=1,not_in_creative_inventory=1, poison_plant=1},
	sounds = default.node_sound_leaves_defaults(),
	drop = "qt:poison_bush1",
	selection_box = {
		type = "fixed",
		fixed = {-0.5, -0.5, -0.5, 0.5, -5/16, 0.5},
	},
})
end

--light plant

minetest.register_node(":qt:poison_light_plant1", {
	description = "Poison Light Plant",
	drawtype = "plantlike",
	waving = 1,
	tiles = {"light_plant1.png"},
	inventory_image = "light_plant4.png",
	wield_image = "light_plant4.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	buildable_to = true,
	groups = {snappy=3,flora=1,attached_node=1, poison_plant=1},
	sounds = default.node_sound_leaves_defaults(),
	selection_box = {
		type = "fixed",
		fixed = {-0.5, -0.5, -0.5, 0.5, -5/16, 0.5},
	},
	on_place = function(itemstack, placer, pointed_thing)
		-- place a random node
		local node = rgen.get_random_data("P_light_plant")
		minetest.set_node(pointed_thing.above, {name = node})
		if not minetest.setting_getbool("creative_mode") then itemstack:take_item() end
		return itemstack
	end,
})

rgen.register_random_data("P_light_plant", "qt:poison_light_plant1")
rgen.register_random_data("P_light_plant", "qt:poison_light_plant2")
rgen.register_random_data("P_light_plant", "qt:poison_light_plant3")
rgen.register_random_data("P_light_plant", "qt:poison_light_plant4")

for i = 2, 4 do
minetest.register_node(":qt:poison_light_plant"..i, {
	description = "Poison Light Plant",
	drawtype = "plantlike",
	waving = 1,
	tiles = {"light_plant"..i..".png"},
	inventory_image = "light_plant"..i..".png",
	wield_image = "light_plant"..i..".png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	buildable_to = true,
	groups = {snappy=3,flora=1,attached_node=1,not_in_creative_inventory=1, poison_plant=1},
	sounds = default.node_sound_leaves_defaults(),
	drop = "qt:poison_light_plant1",
	selection_box = {
		type = "fixed",
		fixed = {-0.5, -0.5, -0.5, 0.5, -5/16, 0.5},
	},
})
end

--tuber

minetest.register_node(":qt:poison_tuber1", {
	description = "Poison Tuber",
	drawtype = "plantlike",
	waving = 1,
	tiles = {"tuber1.png"},
	inventory_image = "tuber3.png",
	wield_image = "tuber3.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	buildable_to = true,
	groups = {snappy=3,flora=1,attached_node=1, poison_plant=1},
	sounds = default.node_sound_leaves_defaults(),
	selection_box = {
		type = "fixed",
		fixed = {-0.5, -0.5, -0.5, 0.5, -5/16, 0.5},
	},
	on_place = function(itemstack, placer, pointed_thing)
		-- place a random node
		local node = rgen.get_random_data("P_tuber")
		minetest.set_node(pointed_thing.above, {name = node})
		if not minetest.setting_getbool("creative_mode") then itemstack:take_item() end
		return itemstack
	end,
})

rgen.register_random_data("P_tuber", "qt:poison_tuber1")
rgen.register_random_data("P_tuber", "qt:poison_tuber2")
rgen.register_random_data("P_tuber", "qt:poison_tuber3")
rgen.register_random_data("P_tuber", "qt:poison_tuber4")
rgen.register_random_data("P_tuber", "qt:poison_tuber5")

for i = 2, 5 do
minetest.register_node(":qt:poison_tuber"..i, {
	description = "Poison Tuber",
	drawtype = "plantlike",
	waving = 1,
	tiles = {"tuber"..i..".png"},
	inventory_image = "tuber"..i..".png",
	wield_image = "tuber"..i..".png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	buildable_to = true,
	groups = {snappy=3,flora=1,attached_node=1,not_in_creative_inventory=1, poison_plant=1},
	sounds = default.node_sound_leaves_defaults(),
	drop = "qt:poison_tuber1",
	selection_box = {
		type = "fixed",
		fixed = {-0.5, -0.5, -0.5, 0.5, -5/16, 0.5},
	},
})
end

--weed

minetest.register_node(":qt:poison_weed1", {
	description = "Poison Weed",
	drawtype = "plantlike",
	waving = 1,
	tiles = {"weed1.png"},
	inventory_image = "weed1.png",
	wield_image = "weed1.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	buildable_to = true,
	groups = {snappy=3,flora=1,attached_node=1, poison_plant=1},
	sounds = default.node_sound_leaves_defaults(),
	selection_box = {
		type = "fixed",
		fixed = {-0.5, -0.5, -0.5, 0.5, -5/16, 0.5},
	},
	on_place = function(itemstack, placer, pointed_thing)
		-- place a random node
		local node = rgen.get_random_data("P_weed")
		minetest.set_node(pointed_thing.above, {name = node})
		if not minetest.setting_getbool("creative_mode") then itemstack:take_item() end
		return itemstack
	end,
})

rgen.register_random_data("P_weed", "qt:poison_weed1")
rgen.register_random_data("P_weed", "qt:poison_weed2")
rgen.register_random_data("P_weed", "qt:poison_weed3")
rgen.register_random_data("P_weed", "qt:poison_weed4")
rgen.register_random_data("P_weed", "qt:poison_weed5")
rgen.register_random_data("P_weed", "qt:poison_weed6")

for i = 2, 6 do
minetest.register_node(":qt:poison_weed"..i, {
	description = "Poison Weed",
	drawtype = "plantlike",
	waving = 1,
	tiles = {"weed"..i..".png"},
	inventory_image = "weed"..i..".png",
	wield_image = "weed"..i..".png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	buildable_to = true,
	groups = {snappy=3,flora=1,attached_node=1, not_in_creative_inventory=1, poison_plant=1},
	sounds = default.node_sound_leaves_defaults(),
	drop = "qt:poison_weed1",
	selection_box = {
		type = "fixed",
		fixed = {-0.5, -0.5, -0.5, 0.5, -5/16, 0.5},
	},
})
end



--P_plants
rgen.register_random_data("P_plants", "qt:poison_grass1")
rgen.register_random_data("P_plants", "qt:poison_grass2")
rgen.register_random_data("P_plants", "qt:poison_grass3")
rgen.register_random_data("P_plants", "qt:poison_bush1")
rgen.register_random_data("P_plants", "qt:poison_bush2")
rgen.register_random_data("P_plants", "qt:poison_bush3")
rgen.register_random_data("P_plants", "qt:poison_bush4")
rgen.register_random_data("P_plants", "qt:poison_bush5")
rgen.register_random_data("P_plants", "qt:poison_bush6")
rgen.register_random_data("P_plants", "qt:poison_light_plant1")
rgen.register_random_data("P_plants", "qt:poison_light_plant2")
rgen.register_random_data("P_plants", "qt:poison_light_plant3")
rgen.register_random_data("P_plants", "qt:poison_light_plant4")
rgen.register_random_data("P_plants", "qt:poison_tuber1")
rgen.register_random_data("P_plants", "qt:poison_tuber2")
rgen.register_random_data("P_plants", "qt:poison_tuber3")
rgen.register_random_data("P_plants", "qt:poison_tuber4")
rgen.register_random_data("P_plants", "qt:poison_tuber5")
rgen.register_random_data("P_plants", "qt:poison_weed1")
rgen.register_random_data("P_plants", "qt:poison_weed2")
rgen.register_random_data("P_plants", "qt:poison_weed3")
rgen.register_random_data("P_plants", "qt:poison_weed4")
rgen.register_random_data("P_plants", "qt:poison_weed5")
rgen.register_random_data("P_plants", "qt:poison_weed6")
rgen.register_random_data("P_plants", "qt:poison_reeds")

rgen.register_random_data("P_is_plant", false)
rgen.register_random_data("P_is_plant", false)
rgen.register_random_data("P_is_plant", false)
rgen.register_random_data("P_is_plant", true)
rgen.register_random_data("P_is_plant", true)
rgen.register_random_data("P_is_plant", true)
rgen.register_random_data("P_is_plant", true)


minetest.register_node(":qt:poison_stone", {
	description = "Poison Stone",
	tiles = {"poison_stone.png"},
	groups = {cracky=3, stone=1},
	legacy_mineral = true,
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_node(":qt:poison_dirt", {
	description = "Poison Dirt",
	tiles = {"poison_dirt.png"},
	groups = {crumbly=3,soil=1},
	sounds = default.node_sound_dirt_defaults(),
})

minetest.register_node(":qt:poison_dirt_with_grass", {
	description = "Poison Dirt with Grass",
	tiles = {"poison_grass.png", "poison_dirt.png",
		{name = "poison_dirt.png^poison_grass_side.png",
			tileable_vertical = false}},
	groups = {crumbly=3,soil=1},
	drop = 'qt:poison_dirt',
	sounds = default.node_sound_dirt_defaults({
		footstep = {name="default_grass_footstep", gain=0.25},
	}),
})

function grow_poison_reeds(pos, node)
	pos.y = pos.y - 1
	local name = minetest.get_node(pos).name
	if name ~= "qt:poison_dirt_with_grass" and name ~= "qt:poison_dirt" then
		return
	end
	if not minetest.find_node_near(pos, 3, {"group:poison"}) then
		return
	end
	pos.y = pos.y + 1
	local height = 0
	while node.name == "qt:poison_reeds" and height < 6 do
		height = height + 1
		pos.y = pos.y + 1
		node = minetest.get_node(pos)
	end
	if height == 6 or node.name ~= "air" then
		return
	end
	minetest.set_node(pos, {name = "qt:poison_reeds"})
	return true
end

minetest.register_abm({
	nodenames = {"qt:poison_reeds"},
	neighbors = {"qt:poison_dirt", "qt:poison_dirt_with_grass"},
	interval = 50,
	chance = 20,
	action = function(...)
		grow_poison_reeds(...)
	end
})

minetest.register_abm({
	nodenames = {"qt:poison_dirt"},
	interval = 2,
	chance = 200,
	action = function(pos, node)
		local above = {x = pos.x, y = pos.y + 1, z = pos.z}
		local name = minetest.get_node(above).name
		local nodedef = minetest.registered_nodes[name]
		if nodedef and (nodedef.sunlight_propagates or nodedef.paramtype == "light") and
				nodedef.liquidtype == "none" and
				(minetest.get_node_light(above) or 0) >= 13 then
			minetest.set_node(pos, {name = "qt:poison_dirt_with_grass"})
		end
	end
})

minetest.register_abm({
	nodenames = {"qt:poison_dirt_with_grass"},
	interval = 2,
	chance = 20,
	action = function(pos, node)
		local above = {x = pos.x, y = pos.y + 1, z = pos.z}
		local name = minetest.get_node(above).name
		local nodedef = minetest.registered_nodes[name]
		if name ~= "ignore" and nodedef and not ((nodedef.sunlight_propagates or
				nodedef.paramtype == "light") and
				nodedef.liquidtype == "none") then
			minetest.set_node(pos, {name = "qt:poison_dirt"})
		end
	end
})


--[[
minetest.register_node(":qt:poison_liquid_source", {
	description = "Poison Source",
	inventory_image = minetest.inventorycube("poison_liquid.png"),
	drawtype = "liquid",
	tiles = {
		{
			name = "poison_liquid_source_animated.png",
			animation = {
				type = "vertical_frames",
				aspect_w = 16,
				aspect_h = 16,
				length = 2.0,
			},
		},
	},
	special_tiles = {
		-- New-style water source material (mostly unused)
		{
			name = "poison_liquid_source_animated.png",
			animation = {
				type = "vertical_frames",
				aspect_w = 16,
				aspect_h = 16,
				length = 2.0,
			},id,
			backface_culling = false,
		},
	},
	alpha = 160,
	paramtype = "light",
	walkable = false,
	pointable = false,
	diggable = false,
	buildable_to = true,
	is_ground_content = false,
	drop = "",
	drowning = 1,
	liquidtype = "source",
	liquid_alternative_flowing = "qt:poison_liquid_flowing",
	liquid_alternative_source = "qt:poison_liquid_source",
	liquid_viscosity = 1,
	liquid_renewable = true,
	damage_per_second = 9,
	post_effect_color = {a=120, r=30, g=60, b=90},
	groups = {poison=3, liquid=3, puts_out_fire=1},
	on_blast = function(pos, intensity)
		--this is blank, so obsidian will not be destroyed
	end,
})

minetest.register_node(":qt:poison_liquid_flowing", {
	description = "Flowing Water",
	inventory_image = minetest.inventorycube("poison_liquid.png"),
	drawtype = "flowingliquid",
	tiles = {"poison_liquid.png"},
	special_tiles = {
		{
			name = "poison_liquid_flowing_animated.png",
			backface_culling = false,
			animation = {
				type = "vertical_frames",
				aspect_w = 16,
				aspect_h = 16,
				length = 0.8,
			},
		},
		{
			name = "poison_liquid_flowing_animated.png",
			backface_culling = true,
			animation = {
				type = "vertical_frames",
				aspect_w = 16,
				aspect_h = 16,
				length = 0.8,
			},
		},
	},
	alpha = 160,
	paramtype = "light",
	paramtype2 = "flowingliquid",
	walkable = false,
	pointable = false,
	diggable = false,
	buildable_to = true,
	is_ground_content = false,
	drop = "",
	drowning = 1,
	liquidtype = "flowing",
	liquid_alternative_flowing = "qt:poison_liquid_flowing",
	liquid_alternative_source = "qt:poison_liquid_source",
	liquid_viscosity = 1,
	liquid_renewable = true,
	damage_per_second = 9,
	post_effect_color = {a=120, r=30, g=60, b=90},
	groups = {poison=3, liquid=3, puts_out_fire=1, not_in_creative_inventory=1},
	on_blast = function(pos, intensity)
		--this is blank, so obsidian will not be destroyed
	end,
})

bucket.register_liquid(
	"qt:poison_liquid_source",
	"qt:poison_liquid_flowing",
	":qt:poison_bucket",
	"bucket_poison.png",
	"Poison Bucket"
)

minetest.register_alias(":qt:poison_bucket", "qt:poison_bucket")
--]]

qt.register_liquid("qt:poison_liquid", {
description = "Poison Liquid",
tiles = {inventory = "poison_liquid.png", source_animated="poison_liquid_source_animated.png", flowing_animated="poison_liquid_flowing_animated.png", bucket="bucket_poison.png"},
alpha = 160,
drowning = 1,
viscosity = 1,
renewable = true,
range = 8,
damage_ber_second = 10,
post_effect_color = {a=120, r=76, g=187, b=106}, --
custom_groups = {poison=3, liquid=3, puts_out_fire=3, not_in_creative_inventory=0},
custom_groups_flowing = {poison=3, liquid=3, puts_out_fire=3, not_in_creative_inventory=1},
})



minetest.register_node(":qt:poison_gem_sponge", {
	description = "Poison Gem Sponge",
	tiles = {"poison_sponge.png"},
	groups = {cracky=3, stone=1},
	legacy_mineral = true,
	sounds = default.node_sound_stone_defaults(),
	drop = 'qt:poison_gem',
})

minetest.register_craftitem(":qt:poison_gem", {
	description = "Poison Gem",
	inventory_image = "poison_gem.png",
})

minetest.register_node(":qt:poison_gem_block", {
	description = "Poison Gem Block",
	tiles = {"poison_gem_block.png"},
	is_ground_content = false,
	groups = {cracky=1,level=3},
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_craft({
	output = 'qt:poison_gem_block',
	recipe = {
		{'qt:poison_gem', 'qt:poison_gem', 'qt:poison_gem'},
		{'qt:poison_gem', 'qt:poison_gem', 'qt:poison_gem'},
		{'qt:poison_gem', 'qt:poison_gem', 'qt:poison_gem'},
	}
})

minetest.register_craft({
	output = 'qt:poison_gem 9',
	recipe = {
		{'qt:poison_gem_block'},
	}
})


minetest.register_abm({
	nodenames = {"qt:poison_liquid_flowing"},
	neighbors = {"group:lava"},
	interval = 1,
	chance = 2,
	action = function(...)
		cool_poison(...)
	end,
})

minetest.register_abm({
	nodenames = {"qt:poison_liquid_source"},
	neighbors = {"group:lava"},
	interval = 1,
	chance = 2,
	action = function(...)
		cool_poison(...)
	end,
})

cool_poison = function(pos)
	minetest.set_node(pos, {name = "qt:poison_gem_sponge"})
	minetest.sound_play("default_cool_lava",
		{pos = pos, max_hear_distance = 16, gain = 0.25})
end

minetest.register_craftitem(":qt:poison_droplet", {
	description = "Poison Droplet",
	inventory_image = "poison_droplet.png",
})

--[[
minetest.register_node(":qt:poison_", {
	description = "",
	drawtype = "plantlike",
	waving = 1,
	tiles = {".png"},
	inventory_image = ".png",
	wield_image = ".png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	buildable_to = true,
	groups = {snappy=3,flammable=2,flora=1,attached_node=1},
	sounds = default.node_sound_leaves_defaults(),
	selection_box = {
		type = "fixed",
		fixed = {-0.5, -0.5, -0.5, 0.5, -5/16, 0.5},
	},
})
--]]





--not_in_creative_inventory=1

