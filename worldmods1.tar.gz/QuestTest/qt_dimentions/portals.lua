minetest.register_node(":qt:nether_warp", {
	description = "Nether Warpstone",
	tiles = {"nether_warp.png"},
	is_ground_content = false,
	groups = {cracky=3, stone=1, dimentional_warp=1},
	sounds = default.node_sound_stone_defaults(),
	on_rightclick = function(pos, node, player, itemstack, pointed_thing)
		local playerpos = player:getpos()
		if playerpos.y > -600 or playerpos.y < -800 then
			player:setpos({x = playerpos.x, y = -670, z = playerpos.z})
			minetest.after(0.3, function()
				for b = 680, 600 do
					local node = minetest.env:get_node({x = playerpos.x, y = 0-b, z = playerpos.z})
					local above = minetest.env:get_node({x = playerpos.x, y = 0-b+1, z = playerpos.z})
					if node.name == "air" and above.name == "air" then
						player:setpos({x = playerpos.x, y = 0-b, z = playerpos.z})
						return
					end
				end
			end)
		else
			player:setpos({x = playerpos.x, y = 10, z = playerpos.z})
			minetest.after(0.3, function()
				for c = 0, 150 do
					local node = minetest.env:get_node({x = playerpos.x, y = c, z = playerpos.z})
					local above = minetest.env:get_node({x = playerpos.x, y = c+1, z = playerpos.z})
					if node.name == "air" and above.name == "air" then
						player:setpos({x = playerpos.x, y = c, z = playerpos.z})
						return
					end
				end
			end)
		end
	end
})

minetest.register_craft({
	output = 'qt:nether_warp',
	recipe = {
		{'default:obsidian', 'default:steel_ingot', 'default:obsidian'},
		{'default:steel_ingot', 'default:steel_ingot', 'default:steel_ingot'},
		{'default:obsidian', 'default:steel_ingot', 'default:obsidian'},
	}
})

minetest.register_node(":qt:miner_warp", {
	description = "Miner's Dimention Warpstone",
	tiles = {"miner_warp.png"},
	is_ground_content = false,
	groups = {cracky=3, stone=1, dimentional_warp=1},
	sounds = default.node_sound_stone_defaults(),
	on_rightclick = function(pos, node, player, itemstack, pointed_thing)
		local playerpos = player:getpos()
		if playerpos.y >= -800 or playerpos.y <= -900 then
			player:setpos({x = playerpos.x, y = -830, z = playerpos.z})
		else
			player:setpos({x = playerpos.x, y = 10, z = playerpos.z})
			minetest.after(0.3, function()
				for c = 0, 150 do
					local node = minetest.env:get_node({x = playerpos.x, y = c, z = playerpos.z})
					local above = minetest.env:get_node({x = playerpos.x, y = c+1, z = playerpos.z})
					if node.name == "air" and above.name == "air" then
						player:setpos({x = playerpos.x, y = c, z = playerpos.z})
						return
					end
				end
			end)
		end
	end
})

minetest.register_craft({
	output = 'qt:miner_warp',
	recipe = {
		{'default:goldblock', 'qt:block_gem_sky_blue', 'default:goldblock'},
		{'qt:block_gem_sky_blue', 'default:goldblock', 'qt:block_gem_sky_blue'},
		{'default:goldblock', 'qt:block_gem_sky_blue', 'default:goldblock'},
	}
})

minetest.register_node(":qt:poison_warp", {
	description = "Poison Dimention Warpstone",
	tiles = {"poison_warp.png"},
	is_ground_content = false,
	groups = {cracky=3, stone=1, dimentional_warp=1},
	sounds = default.node_sound_stone_defaults(),
	on_rightclick = function(pos, node, player, itemstack, pointed_thing)
		local playerpos = player:getpos()
		if playerpos.y >= -891 or playerpos.y <= -990 then
			player:setpos({x = playerpos.x, y = -940, z = playerpos.z})
		else
			player:setpos({x = playerpos.x, y = 10, z = playerpos.z})
			minetest.after(0.3, function()
				for c = 0, 150 do
					local node = minetest.env:get_node({x = playerpos.x, y = c, z = playerpos.z})
					local above = minetest.env:get_node({x = playerpos.x, y = c+1, z = playerpos.z})
					if node.name == "air" and above.name == "air" then
						player:setpos({x = playerpos.x, y = c, z = playerpos.z})
						return
					end
				end
			end)
		end
	end
})

minetest.register_craft({
	output = 'qt:poison_warp',
	recipe = {
		{'qt:jade_block', 'qt:jade_block', 'qt:jade_block'},
		{'qt:jade_block', 'default:steelblock', 'qt:jade_block'},
		{'qt:jade_block', 'qt:jade_block', 'qt:jade_block'},
	}
})



