--qt

minetest.register_craftitem(":qt:blueprint", {
	description = "Blueprint",
	inventory_image = "blueprint.png",
})

minetest.register_craft({
	output = 'qt:blueprint',
	recipe = {
		{'default:paper', 'group:unicolor_blue'},
	}
})

minetest.register_node(":qt:pumpkin_block", {
	description = "Pumpkin",
	tiles = {"pumpkin_top.png", "pumpkin_bottom.png", "pumpkin_side.png"},
	paramtype2 = "facedir",
	is_ground_content = false,
	groups = {choppy=2,oddly_breakable_by_hand=1,flammable=2},
	sounds = default.node_sound_wood_defaults(),
	on_place = minetest.rotate_node
})

minetest.register_craft({
	output = 'qt:pumpkin_block',
	recipe = {
		{'qt:pumpkin', 'qt:pumpkin', 'qt:pumpkin'},
		{'qt:pumpkin', '', 'qt:pumpkin'},
		{'qt:pumpkin', 'qt:pumpkin', 'qt:pumpkin'},
	}
})

minetest.register_node(":qt:jackolantern", {
	description = "Jack'o'lantern",
	tiles = {"pumpkin_top.png", "pumpkin_bottom.png", "pumpkin_side.png",
		"pumpkin_side.png", "pumpkin_side.png", "pumpkin_jackolantern.png"},
	paramtype2 = "facedir",
	legacy_facedir_simple = true,
	light_source = LIGHT_MAX-1,
	is_ground_content = false,
	groups = {choppy=2,oddly_breakable_by_hand=1,flammable=2},
	drop = {
		max_items = 2,
		items = {
			{
				items = {'qt:pumpkin_block'},
			},
			{
				items = {'default:torch'},
			}
		}
	},
	sounds = default.node_sound_wood_defaults(),
})

minetest.register_craft({
	output = 'qt:jackolantern',
	recipe = {
		{'qt:pumpkin', 'qt:pumpkin', 'qt:pumpkin'},
		{'qt:pumpkin', 'default:torch', 'qt:pumpkin'},
		{'qt:pumpkin', 'qt:pumpkin', 'qt:pumpkin'},
	}
})

minetest.register_craft({
	output = 'qt:jackolantern',
	recipe = {
		{'qt:pumpkin_block', 'default:torch'},
	}
})

minetest.register_craft({
	output = 'qt:pumpkin 8',
	recipe = {
		{'qt:pumpkin_block'},
	}
})

minetest.register_craftitem(":qt:zombie_l1", {
	description = "Construct Basic Zombie Dungeon",
	inventory_image = "construct_dungeon.png",
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.above then
			local file = io.open(minetest.get_modpath("qt_dungeons").."/schemes/zombie_minor.we")
			local value = file:read("*a")
			file:close()
			local p = pointed_thing.above
			p.x = p.x - 5
			p.z = p.z - 2
			local count = worldedit.deserialize(pointed_thing.above, value)
			itemstack:take_item()
		end
		return itemstack
	end,
})

minetest.register_craft({
	output = 'qt:zombie_l1',
	recipe = {
		{'group:stone', 'group:stone', 'group:stone'},
		{'group:stone', 'qt:rotten_flesh', 'group:stone'},
		{'group:stone', 'qt:blueprint', 'group:stone'},
	}
})

minetest.register_craftitem(":qt:zombie_l2", {
	description = "Construct Advanced Zombie Dungeon",
	inventory_image = "construct_dungeon.png",
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.above then
			local file = io.open(minetest.get_modpath("qt_dungeons").."/schemes/zombie_major.we")
			local value = file:read("*a")
			file:close()
			local p = pointed_thing.above
			p.x = p.x - 5
			p.z = p.z - 2
			local count = worldedit.deserialize(pointed_thing.above, value)
			itemstack:take_item()
		end
		return itemstack
	end,
})

minetest.register_craft({
	output = 'qt:zombie_l2',
	recipe = {
		{'default:stonebrick', 'default:stonebrick', 'default:stonebrick'},
		{'default:stonebrick', 'qt:rotten_flesh', 'default:stonebrick'},
		{'default:stonebrick', 'qt:blueprint', 'default:stonebrick'},
	}
})

minetest.register_craftitem(":qt:skeleton_l1", {
	description = "Construct Basic Skeleton Dungeon",
	inventory_image = "construct_dungeon.png",
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.above then
			local file = io.open(minetest.get_modpath("qt_dungeons").."/schemes/skeleton_minor.we")
			local value = file:read("*a")
			file:close()
			local p = pointed_thing.above
			p.x = p.x - 5
			p.z = p.z - 2
			local count = worldedit.deserialize(pointed_thing.above, value)
			itemstack:take_item()
		end
		return itemstack
	end,
})

minetest.register_craft({
	output = 'qt:skeleton_l1',
	recipe = {
		{'group:stone', 'group:stone', 'group:stone'},
		{'group:stone', 'qt:bone', 'group:stone'},
		{'group:stone', 'qt:blueprint', 'group:stone'},
	}
})

minetest.register_craftitem(":qt:skeleton_l2", {
	description = "Construct Advanced Skeleton Dungeon",
	inventory_image = "construct_dungeon.png",
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.above then
			local file = io.open(minetest.get_modpath("qt_dungeons").."/schemes/skeleton_major.we")
			local value = file:read("*a")
			file:close()
			local p = pointed_thing.above
			p.x = p.x - 5
			p.z = p.z - 2
			local count = worldedit.deserialize(pointed_thing.above, value)
			itemstack:take_item()
		end
		return itemstack
	end,
})

minetest.register_craft({
	output = 'qt:skeleton_l2',
	recipe = {
		{'default:stonebrick', 'default:stonebrick', 'default:stonebrick'},
		{'default:stonebrick', 'qt:bone', 'default:stonebrick'},
		{'default:stonebrick', 'qt:blueprint', 'default:stonebrick'},
	}
})

minetest.register_craftitem(":qt:tower_l1", {
	description = "Construct level 1 Tower Dungeon",
	inventory_image = "construct_dungeon.png",
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.above then
			local file = io.open(minetest.get_modpath("qt_dungeons").."/schemes/tower1.we")
			local value = file:read("*a")
			file:close()
			local p = pointed_thing.above
			p.x = p.x - 5
			p.z = p.z - 2
			local count = worldedit.deserialize(pointed_thing.above, value)
			itemstack:take_item()
		end
		return itemstack
	end,
})

minetest.register_craft({
	output = 'qt:tower_l1',
	recipe = {
		{'qt:zombie_l2'},
		{'qt:skeleton_l2'},
		{'qt:zombie_l2'},
	}
})


minetest.register_craftitem(":qt:pumpkin_zombie", {
	description = "Construct Pumpkin Zombie Dungeon",
	inventory_image = "construct_dungeon.png",
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.above then
			local file = io.open(minetest.get_modpath("qt_dungeons").."/schemes/pumpkin_dungeon.we")
			local value = file:read("*a")
			file:close()
			local p = pointed_thing.above
			p.x = p.x - 5
			p.z = p.z - 2
			local count = worldedit.deserialize(pointed_thing.above, value)
			itemstack:take_item()
		end
		return itemstack
	end,
})

minetest.register_craft({
	output = 'qt:pumpkin_zombie',
	recipe = {
		{'default:stone', 'default:obsidian', 'default:stone'},
		{'default:obsidian', 'qt:rotten_flesh', 'default:obsidian'},
		{'default:obsidian', 'qt:blueprint', 'default:obsidian'},
	}
})

minetest.register_craftitem(":qt:nether_basic", {
	description = "Construct Nether Dungeon",
	inventory_image = "construct_dungeon.png",
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.above then
			local file = io.open(minetest.get_modpath("qt_dungeons").."/schemes/nether_dungeon.we")
			local value = file:read("*a")
			file:close()
			local p = pointed_thing.above
			p.x = p.x - 5
			p.z = p.z - 2
			local count = worldedit.deserialize(pointed_thing.above, value)
			itemstack:take_item()
		end
		return itemstack
	end,
})

minetest.register_craft({
	output = 'qt:nether_basic',
	recipe = {
		{'qt:nether_stone', 'qt:nether_stone', 'qt:nether_stone'},
		{'qt:nether_stone', 'qt:blueprint', 'qt:nether_stone'},
		{'qt:nether_stone', 'qt:nether_stone', 'qt:nether_stone'},
	}
})

minetest.register_craftitem(":qt:nether_castle", {
	description = "Construct Nether Castle Dungeon",
	inventory_image = "construct_dungeon.png",
	on_place = function(itemstack, placer, pointed_thing)
		if pointed_thing.above then
			local file = io.open(minetest.get_modpath("qt_dungeons").."/schemes/nether_castle.we")
			local value = file:read("*a")
			file:close()
			local p = pointed_thing.above
			p.x = p.x - 5
			p.z = p.z - 2
			local count = worldedit.deserialize(pointed_thing.above, value)
			itemstack:take_item()
		end
		return itemstack
	end,
})

minetest.register_craft({
	output = 'qt:nether_castle',
	recipe = {
		{'qt:nether_stone', 'default:obsidianbrick', 'qt:nether_stone'},
		{'default:obsidianbrick', 'qt:netherite_gem', 'default:obsidianbrick'},
		{'qt:nether_stone', 'qt:blueprint', 'qt:nether_stone'},
	}
})
