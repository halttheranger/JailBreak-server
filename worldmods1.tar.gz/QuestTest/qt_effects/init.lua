--qt_effects
--this mod adds status effects

playereffects.register_effect_type("speed", "Speed 1", nil, {"speed"},
	function(player)
		player:set_physics_override(2,1.1,nil)
	end,

	function(effect, player)
		player:set_physics_override(1,1,nil)
	end
)

playereffects.register_effect_type("slowness", "Slowness 1", nil, {"slowness"},
	function(player)
		player:set_physics_override(.5,nil,nil)
	end,

	function(effect, player)
		player:set_physics_override(1,nil,nil)
	end
)

playereffects.register_effect_type("jump_boost", "Jump Boost 1", nil, {"jump"},
	function(player)
		player:set_physics_override(nil,2,nil)
	end,
	function(effect, player)
		player:set_physics_override(nil,1,nil)
	end
)

--non physics-overriding effects

playereffects.register_effect_type("regen", "Regeneration", "heart.png", {"regen"},
	function(player)
		player:set_hp(player:get_hp()+1)
	end,
	nil, nil, nil, 0.5
)

playereffects.register_effect_type("regen_2", "Regeneration 2", "heart.png", {"regen"},
	function(player)
		player:set_hp(player:get_hp()+2)
	end,
	nil, nil, nil, 0.5
)


playereffects.register_effect_type("speed_and_jump", "Jump Boost 1", nil, {"jump", "speed"},
	function(player)
		player:set_physics_override(2,2,nil)
	end,
	function(effect, player)
		player:set_physics_override(1,1,nil)
	end
)


--experimental tools to test the application of a status effect.
minetest.register_tool("qt_effects:speed_item", {
	description = "Speed Item",
	inventory_image = "magic_wand.png",
	on_use = function (itemstack, user, pointed_thing)
		playereffects.apply_effect_type("speed", 60, user)
	end
})

minetest.register_tool("qt_effects:slowness_item", {
	description = "Slowness Item",
	inventory_image = "magic_wand.png",
	on_use = function (itemstack, user, pointed_thing)
		playereffects.apply_effect_type("slowness", 60, user)
	end
})

minetest.register_tool("qt_effects:jump_item", {
	description = "Jump Boost Item",
	inventory_image = "magic_wand.png",
	on_use = function (itemstack, user, pointed_thing)
		playereffects.apply_effect_type("jump_boost", 60, user)
	end
})


--useful chatcommand to cancel all effects

minetest.register_chatcommand("cancelall", {
	params = "",
	description = "Cancels all your effects.",
	privs = {},
	func = function(name, param)
		local effects = playereffects.get_player_effects(name)
		for e=1, #effects do
			playereffects.cancel_effect(effects[e].effect_id)
		end
		minetest.chat_send_player(name, "All effects cancelled.")
	end,
})
