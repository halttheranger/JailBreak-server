--qt


minetest.register_node(":qt:glowstone", {
	description = "Glowstone",
	tiles = {"glowstone.png"},
	is_ground_content = false,
	groups = {cracky=3, glowstone=1},
	light_source = LIGHT_MAX,
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_craftitem(":qt:glow_stick", {
	description = "Glowing Stick",
	inventory_image = "glowstone_rod.png",
	groups = {glowstuff=1},
})

minetest.register_craftitem(":qt:glow_dust", {
	description = "Glowing Dust",
	inventory_image = "glowstone_dust.png",
	groups = {glowstuff=1},
})

--crafting
minetest.register_craft({
	output = 'qt:glowstone',
	recipe = {
		{'group:glowstuff', 'group:glowstuff', 'group:glowstuff'},
		{'group:glowstuff', 'group:glowstuff', 'group:glowstuff'},
		{'group:glowstuff', 'group:glowstuff', 'group:glowstuff'},
	}
})

minetest.register_craft({
	output = 'qt:glow_stick 3',
	recipe = {
		{'', '', 'qt:glow_dust'},
		{'', 'qt:glow_dust', ''},
		{'qt:glow_dust', '', ''},
	}
})

minetest.register_craft({
	output = 'qt:glow_dust 9',
	recipe = {
		{'qt:glowstone'},
	}
})

minetest.register_craft({
	output = 'qt:glow_dust',
	recipe = {
		{'qt:glow_stick'},
	}
})

minetest.register_craft({
	output = 'qt:glowstone',
	recipe = {
		{'default:stone', 'default:glass', 'default:stone'},
		{'default:glass', 'default:torch', 'default:glass'},
		{'default:stone', 'default:glass', 'default:stone'},
	}
})
