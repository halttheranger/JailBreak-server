--qt

minetest.register_craftitem(":qt:magic_dust", {
	description = "Magical Dust",
	inventory_image = "magic_dust.png",
})

minetest.register_craft({
	type = "shapeless",
	output = 'qt:magic_dust',
	recipe = {'default:mese_crystal', 'qt:farmite_powder', 'qt:olmite_powder'},
})

minetest.register_node(":qt:magic_apple", {
	description = "Magical Apple",
	drawtype = "plantlike",
	visual_scale = 1.0,
	tiles = {"magic_apple.png"},
	inventory_image = "magic_apple.png",
	paramtype = "light",
	sunlight_propagates = true,
	walkable = false,
	is_ground_content = false,
	selection_box = {
		type = "fixed",
		fixed = {-0.2, -0.5, -0.2, 0.2, 0, 0.2}
	},
	groups = {fleshy=3,dig_immediate=3,flammable=2},
	on_use = function(itemstack,user, pointed_thing)
		user:set_hp(user:get_hp()+20)
		itemstack:take_item(1)
		playereffects.apply_effect_type("speed_and_jump", 60, user)
		playereffects.apply_effect_type("regen_2", 50, user)
		return itemstack
	end,
	sounds = default.node_sound_leaves_defaults(),
	after_place_node = function(pos, placer, itemstack)
		if placer:is_player() then
			minetest.set_node(pos, {name="qt:magic_apple", param2=1})
		end
	end,
})

minetest.register_craft({
	output = 'qt:magic_apple',
	recipe = {
		{'qt:magic_dust', 'qt:magic_dust', 'qt:magic_dust'},
		{'qt:magic_dust', 'default:apple', 'qt:magic_dust'},
		{'qt:magic_dust', 'qt:magic_dust', 'qt:magic_dust'},
	}
})

minetest.register_tool(":qt:magic_wand", {
	description = "Magical Wand",
	inventory_image = "magic_wand.png",
	on_use = function (itemstack, user, pointed_thing)
		if pointed_thing.above ~= nil then
			minetest.remove_node (pointed_thing.under)
			minetest.set_node({x=pointed_thing.under.x, y=pointed_thing.under.y, z=pointed_thing.under.z}, {name="default:mese"})
			itemstack:add_wear(65535/20)
			return itemstack
		end
	end
})

minetest.register_craft({
	output = 'qt:magic_wand',
	recipe = {
		{'group:stick'},
		{'qt:magic_dust'},
		{'group:stick'},
	}
})

-- magical tool repair

--default tools
minetest.register_craft({
	type = "shapeless",
	output = 'default:pick_wood',
	recipe = {'default:pick_wood', 'qt:magic_dust'},
})

minetest.register_craft({
	type = "shapeless",
	output = 'default:pick_stone',
	recipe = {'default:pick_stone', 'qt:magic_dust'},
})

minetest.register_craft({
	type = "shapeless",
	output = 'default:pick_steel',
	recipe = {'default:pick_steel', 'qt:magic_dust'},
})

minetest.register_craft({
	type = "shapeless",
	output = 'default:pick_mese',
	recipe = {'default:pick_mese', 'qt:magic_dust'},
})

minetest.register_craft({
	type = "shapeless",
	output = 'default:pick_diamond',
	recipe = {'default:pick_diamond', 'qt:magic_dust'},
})

minetest.register_craft({
	type = "shapeless",
	output = 'default:pick_bronze',
	recipe = {'default:pick_bronze', 'qt:magic_dust'},
})

minetest.register_craft({
	type = "shapeless",
	output = 'default:shovel_wood',
	recipe = {'default:shovel_wood', 'qt:magic_dust'},
})

minetest.register_craft({
	type = "shapeless",
	output = 'default:shovel_stone',
	recipe = {'default:shovel_stone', 'qt:magic_dust'},
})

minetest.register_craft({
	type = "shapeless",
	output = 'default:shovel_steel',
	recipe = {'default:shovel_steel', 'qt:magic_dust'},
})

minetest.register_craft({
	type = "shapeless",
	output = 'default:shovel_mese',
	recipe = {'default:shovel_mese', 'qt:magic_dust'},
})

minetest.register_craft({
	type = "shapeless",
	output = 'default:shovel_diamond',
	recipe = {'default:shovel_diamond', 'qt:magic_dust'},
})

minetest.register_craft({
	type = "shapeless",
	output = 'default:shovel_bronze',
	recipe = {'default:shovel_bronze', 'qt:magic_dust'},
})

minetest.register_craft({
	type = "shapeless",
	output = 'default:axe_wood',
	recipe = {'default:axe_wood', 'qt:magic_dust'},
})

minetest.register_craft({
	type = "shapeless",
	output = 'default:axe_stone',
	recipe = {'default:axe_stone', 'qt:magic_dust'},
})

minetest.register_craft({
	type = "shapeless",
	output = 'default:axe_steel',
	recipe = {'default:axe_steel', 'qt:magic_dust'},
})

minetest.register_craft({
	type = "shapeless",
	output = 'default:axe_mese',
	recipe = {'default:axe_mese', 'qt:magic_dust'},
})

minetest.register_craft({
	type = "shapeless",
	output = 'default:axe_diamond',
	recipe = {'default:axe_diamond', 'qt:magic_dust'},
})

minetest.register_craft({
	type = "shapeless",
	output = 'default:axe_bronze',
	recipe = {'default:axe_bronze', 'qt:magic_dust'},
})

minetest.register_craft({
	type = "shapeless",
	output = 'default:sword_wood',
	recipe = {'default:sword_wood', 'qt:magic_dust'},
})

minetest.register_craft({
	type = "shapeless",
	output = 'default:sword_stone',
	recipe = {'default:sword_stone', 'qt:magic_dust'},
})

minetest.register_craft({
	type = "shapeless",
	output = 'default:sword_steel',
	recipe = {'default:sword_steel', 'qt:magic_dust'},
})

minetest.register_craft({
	type = "shapeless",
	output = 'default:sword_mese',
	recipe = {'default:sword_mese', 'qt:magic_dust'},
})

minetest.register_craft({
	type = "shapeless",
	output = 'default:sword_diamond',
	recipe = {'default:sword_diamond', 'qt:magic_dust'},
})

minetest.register_craft({
	type = "shapeless",
	output = 'default:sword_bronze',
	recipe = {'default:sword_bronze', 'qt:magic_dust'},
})

--my stuff
minetest.register_craft({
	type = "shapeless",
	output = 'qt:magic_wand',
	recipe = {'qt:magic_wand', 'qt:magic_dust'},
})

minetest.register_craft({
	type = "shapeless",
	output = 'qt:pick_red_gem',
	recipe = {'qt:pick_red_gem', 'qt:magic_dust'},
})

minetest.register_craft({
	type = "shapeless",
	output = 'qt:shovel_red_gem',
	recipe = {'qt:shovel_red_gem', 'qt:magic_dust'},
})

minetest.register_craft({
	type = "shapeless",
	output = 'qt:axe_red_gem',
	recipe = {'qt:axe_red_gem', 'qt:magic_dust'},
})

minetest.register_craft({
	type = "shapeless",
	output = 'qt:sword_red_gem',
	recipe = {'qt:sword_red_gem', 'qt:magic_dust'},
})

minetest.register_craft({
	type = "shapeless",
	output = 'qt:pick_green_gem',
	recipe = {'qt:pick_green_gem', 'qt:magic_dust'},
})

minetest.register_craft({
	type = "shapeless",
	output = 'qt:shovel_green_gem',
	recipe = {'qt:shovel_green_gem', 'qt:magic_dust'},
})

minetest.register_craft({
	type = "shapeless",
	output = 'qt:axe_green_gem',
	recipe = {'qt:axe_green_gem', 'qt:magic_dust'},
})

minetest.register_craft({
	type = "shapeless",
	output = 'qt:sword_green_gem',
	recipe = {'qt:sword_green_gem', 'qt:magic_dust'},
})

minetest.register_craft({
	type = "shapeless",
	output = 'qt:pick_blue_gem',
	recipe = {'qt:pick_blue_gem', 'qt:magic_dust'},
})

minetest.register_craft({
	type = "shapeless",
	output = 'qt:shovel_blue_gem',
	recipe = {'qt:shovel_blue_gem', 'qt:magic_dust'},
})

minetest.register_craft({
	type = "shapeless",
	output = 'qt:axe_blue_gem',
	recipe = {'qt:axe_blue_gem', 'qt:magic_dust'},
})

minetest.register_craft({
	type = "shapeless",
	output = 'qt:sword_blue_gem',
	recipe = {'qt:sword_blue_gem', 'qt:magic_dust'},
})

minetest.register_craft({
	type = "shapeless",
	output = 'qt:pick_sky_blue_gem',
	recipe = {'qt:pick_sky_blue_gem', 'qt:magic_dust'},
})

minetest.register_craft({
	type = "shapeless",
	output = 'qt:shovel_sky_blue_gem',
	recipe = {'qt:shovel_sky_blue_gem', 'qt:magic_dust'},
})

minetest.register_craft({
	type = "shapeless",
	output = 'qt:axe_sky_blue_gem',
	recipe = {'qt:axe_sky_blue_gem', 'qt:magic_dust'},
})

minetest.register_craft({
	type = "shapeless",
	output = 'qt:sword_sky_blue_gem',
	recipe = {'qt:sword_sky_blue_gem', 'qt:magic_dust'},
})

minetest.register_craft({
	type = "shapeless",
	output = 'qt:pick_obsidian',
	recipe = {'qt:pick_obsidian', 'qt:magic_dust'},
})

minetest.register_craft({
	type = "shapeless",
	output = 'qt:shovel_obsidian',
	recipe = {'qt:shovel_obsidian', 'qt:magic_dust'},
})

minetest.register_craft({
	type = "shapeless",
	output = 'qt:axe_obsidian',
	recipe = {'qt:axe_obsidian', 'qt:magic_dust'},
})

minetest.register_craft({
	type = "shapeless",
	output = 'qt:sword_obsidian',
	recipe = {'qt:sword_obsidian', 'qt:magic_dust'},
})

minetest.register_craft({
	type = "shapeless",
	output = 'qt:wand_blue_gem',
	recipe = {'qt:wand_blue_gem', 'qt:magic_dust'},
})

minetest.register_craft({
	type = "shapeless",
	output = 'qt:wand_red_gem',
	recipe = {'qt:wand_red_gem', 'qt:magic_dust'},
})

minetest.register_craft({
	type = "shapeless",
	output = 'qt:wand_green_gem',
	recipe = {'qt:wand_green_gem', 'qt:magic_dust'},
})

minetest.register_craft({
	type = "shapeless",
	output = 'qt:wand_sky_blue_gem',
	recipe = {'qt:wand_sky_blue_gem', 'qt:magic_dust'},
})

minetest.register_craft({
	type = "shapeless",
	output = 'qt:wand_blue_gem_replacer',
	recipe = {'qt:wand_blue_gem_replacer', 'qt:magic_dust'},
})

minetest.register_craft({
	type = "shapeless",
	output = 'qt:wand_red_gem_replacer',
	recipe = {'qt:wand_red_gem_replacer', 'qt:magic_dust'},
})

minetest.register_craft({
	type = "shapeless",
	output = 'qt:disrupter',
	recipe = {'qt:disrupter', 'qt:magic_dust'},
})

