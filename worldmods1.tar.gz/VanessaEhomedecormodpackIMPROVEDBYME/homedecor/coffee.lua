local S;
if (minetest.get_modpath("intllib")) then
    dofile(minetest.get_modpath("intllib").."/intllib.lua");
    S = intllib.Getter(minetest.get_current_modname());
else
    S = function ( s ) return s; end
end

local timer = 0;

minetest.register_craftitem("homedecor:coffee_cup", {
    description = S("Cup of Coffee");
    inventory_image = "homedecor_coffee_cup.png";
    groups = { drink=1; survival_no_override=1; };
    stack_max = 10;
    on_use = function ( itemstack, user, pointed_thing )
        local state = survival.get_player_state(user:get_player_name(), "thirst");
        state.count = 0;
        state.thirsty = false;
            to_player = user:getpos();
            gain = 1.0;
        });
        local inv = user:get_inventory();
        local stack = ItemStack("vessels:drinking_glass");
        if (inv:room_for_item("main", stack)) then
            inv:add_item("main", stack);
        end
        itemstack:take_item(1);
        return itemstack;
    end;
});

local alt_coffee_sources = {
    ["homedecor:coffee_maker"] = true;

};

minetest.register_craftitem(":vessels:drinking_glass", {
	--Or use minetest.registered_items[vessels:drinking_glass] for all parametre.
	description = S("Drinking Glass (empty)"),
	drawtype = "plantlike",
	tiles = {"vessels_drinking_glass.png"},
	inventory_image = "vessels_drinking_glass_inv.png",
	wield_image = "vessels_drinking_glass.png",
	paramtype = "light",
	walkable = false,
	selection_box = {
		type = "fixed",
		fixed = {-0.25, -0.5, -0.25, 0.25, 0.4, 0.25}
	},
	groups = {vessel=1,dig_immediate=3,attached_node=1},
	sounds = default.node_sound_glass_defaults(),
	liquids_pointable = true,
	on_use = function(itemstack, user, pointed_thing)
		if pointed_thing.type ~= "node" then
			return
		end
		local node = minetest.get_node(pointed_thing.under)
		if alt_coffee_sources[node.name] then
			local newitem = ItemStack("homedecor:coffee_cup 1");
			local inv = user:get_inventory();
			if (inv:room_for_item("main", newitem)) then
				inv:add_item("main", newitem);
				if not(minetest.registered_items[node.name].liquidtype=="none") then
					minetest.remove_node(pointed_thing.under);
				end
				itemstack:take_item(); 
				return itemstack
			end
		end	
	end,
})
