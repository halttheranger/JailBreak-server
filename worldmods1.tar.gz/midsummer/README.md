# midsummer

Midsummer, the most important swedish tradition. This mod adds the pieces to make a midsummers pole and a swedish flag. And don't forget to climb 7 fences and gather 7 flowers and put under your pillow (then you will dream about your soulmate so you can find him/her/them). Happy Midsummers-eve!

Textures and code by Catninja 19-06-15
The default package and lott is used as a brief base. Nodeboxeditor is used for nodeboxes.
