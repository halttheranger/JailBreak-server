
minetest.register_node(":default:stone_brick", {
	description = "Stone Brick",
	tiles = {"default_stone_brick.png"},
	is_ground_content = false,
	paramtype = "light",
	walkable = false,
	groups = {cracky = 5},
})

police = {}

police = {
    players = {},
    effects = {
        phys_override = function(sname, name, fname, time, sdata, flags)
            local def = {
                on_use = function(itemstack, user, pointed_thing)
                    police.grant(time, user:get_player_name(), fname.."_"..flags.type..sdata.type, name, flags)
                    itemstack:take_item()
                    return itemstack
                end,
                police = {
                    speed = 0,
                    jump = 0,
                    gravity = 0,
                    air = 0,
                },
            }
            return def
        end,
        fixhp = function(sname, name, fname, time, sdata, flags)
            local def = {
                on_use = function(itemstack, user, pointed_thing)
                    for i=0, (sdata.time or 0) do
                        minetest.after(i, function()
                            local hp = user:get_hp()
                            if flags.inv==true then
                                hp = hp - (sdata.hp or 3)
                            else
                                hp = hp + (sdata.hp or 3)
                            end
                            hp = math.min(20, hp)
                            hp = math.max(0, hp)
                            user:set_hp(hp)
                        end)
                    end
                    itemstack:take_item()
                    return itemstack
                end,
            }
            def.mobs = {
                on_near = def.on_use,
            }
            return def
        end,
        air = function(sname, name, fname, time, sdata, flags)
            local def = {
                on_use = function(itemstack, user, pointed_thing)
                    local police_e = police.players[user:get_player_name()]
                    police_e.air = police_e.air + (sdata.time or 0)
                    for i=0, (sdata.time or 0) do
                        minetest.after(i, function()
                            local br = user:get_breath()
                            if flags.inv==true then
                                br = br - (sdata.br or 3)
                            else
                                br = br + (sdata.br or 3)
                            end
                            br = math.min(11, br)
                            br = math.max(0, br)
                            user:set_breath(br)
                            
                            if i==(sdata.time or 0) then
                                police_e.air = police_e.air - (sdata.time or 0)
                            end
                        end)
                    end
                    itemstack:take_item()
                    return itemstack
                end,
            }
            return def
        end,
    },
    grant = function(time, playername, potion_name, type, flags)
        local rootdef = minetest.registered_items[potion_name]
        if rootdef == nil then
            return
        end
        if rootdef.police == nil then
            return
        end
        local def = {}
        for name, val in pairs(rootdef.police) do
            def[name] = val
        end
        if flags.inv==true then
            def.gravity = 0 - def.gravity
            def.speed = 0 - def.speed
            def.jump = 0 - def.jump
        end
        police.addPrefs(playername, def.speed, def.jump, def.gravity)
        police.refresh(playername)
        minetest.chat_send_player(playername, "You are under the effects of a "..type.." shot.")
        minetest.after(time, function()
            police.addPrefs(playername, 0-def.speed, 0-def.jump, 0-def.gravity)
            police.refresh(playername)
            minetest.chat_send_player(playername, "The effects of the "..type.." has worn off.")
        end)
    end,
    addPrefs = function(playername, speed, jump, gravity)
        local prefs = police.players[playername]
        prefs.speed = prefs.speed + speed
        prefs.jump = prefs.jump + jump
        prefs.gravity = prefs.gravity + gravity
    end,
    refresh = function(playername)
        if minetest.get_player_by_name(playername)~=nil then
            local prefs = police.players[playername]
            minetest.get_player_by_name(playername):set_physics_override(prefs.speed, prefs.jump, prefs.gravity)
        end
    end,
    register_potion = function(sname, name, fname, time, def)
        local tps = {"power", "corruption"}
        for t=1, #tps do
            for i=1, #def.types do
                local sdata = def.types[i]
                local item_def = {
                    description = name.." (Strength: "..tps[t]..sdata.type..")",
                    inventory_image = "police_bottle.png^police_"..(def.texture or sname)..".png^police_"..tps[t]..sdata.type..".png",
                    drawtype = "plantlike",
                    paramtype = "light",
                    walkable = false,
                    groups = {dig_immediate=3,attached_node=1,vessel=1},
                }
                item_def.tiles = {item_def.inventory_image}
                local flags = {
                    inv = false,
                    type = tps[t],
                }
                if t == 2 then
                    flags.inv = true
                end
                for name, val in pairs(police.effects[def.effect](sname, name, fname, time, sdata, flags)) do
                    item_def[name] = val
                end
                for name, val in pairs(sdata.set) do
                    item_def[name] = val
                end
                for name, val in pairs(sdata.effects) do
                    item_def.police[name] = val
                end
                    minetest.register_node(fname.."_"..tps[t]..sdata.type, item_def)
                --potions.register_liquid(i..tps[t]..sname, name.." ("..tps[t].." "..i..")", item_def.on_use)
                if minetest.get_modpath("lottthrowing")~=nil then
                    police.register_arrow(fname.."_"..tps[t]..sdata.type, i..tps[t]..sname, name.." ("..tps[t].." "..i..")", item_def.on_use,
                            item_def.description, item_def.inventory_image)
                end
            end
        end
    end,
}
dofile(minetest.get_modpath("police").."/arrows.lua")
     
police.register_potion("taser", "Taser", "police:taser", 240, {
    effect = "phys_override",
    types = {
        {
            type = 1,
            set = {},
            effects = {
                    jump = -0.9,
                    speed = -0.9,
            },
        },
        {
            type = 2,
            set = {},
            effects = {
                    jump = -0.9,
                    speed = -0.9,
            },
        },
        {
            type = 3,
            set = {},
            effects = {
                    jump = -9,
                    speed = -0.9,
            },
        },
    }
})

minetest.register_on_joinplayer(function(player)
    police.players[player:get_player_name()] = {
        speed = 1,
        jump = 1,
        gravity = 1,
        air = 0,
    }
end)

minetest.register_chatcommand("effect", {
    params = "none",
    description = "get effect info",
    func = function(name, param)
        minetest.chat_send_player(name, "effects:")
        local police_e = police.players[name]
        if police_e~=nil then
            for potion_name, val in pairs(lottpotion_e) do
                minetest.chat_send_player(name, potion_name .. "=" .. val)
            end
        end
    end,
})
function police.can_dig(pos, player)
    local meta = minetest.get_meta(pos)
    local inv = meta:get_inventory()
    if not inv:is_empty("src") or not inv:is_empty("dst") or not inv:is_empty("fuel") or
       not inv:is_empty("upgrade1") or not inv:is_empty("upgrade2") then
        minetest.chat_send_player(player:get_player_name(),
            "Brewer cannot be removed because it is not empty")
        return false
    else
        return true
    end
end

function police.swap_node(pos, name)
    local node = minetest.get_node(pos)
    if node.name ~= name then
        node.name = name
        minetest.swap_node(pos, node)
    end
    return node.name
end

