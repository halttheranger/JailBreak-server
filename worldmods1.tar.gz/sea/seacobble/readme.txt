Sounds:
sounds = default.node_sound_stone_defaults()

Copyright (C) 2010-2012 celeron55, Perttu Ahola <celeron55@gmail.com>

Attribution-ShareAlike 3.0 Unported (CC BY-SA 3.0)
http://creativecommons.org/licenses/by-sa/3.0/


Cobble texture is based on:
.png's:
default_cobble.png
Originating from G4JC's Almost MC Texture Pack


Code:
minetest/games/minetest_game/mods/default/nodes.lua --> cobble

Copyright (C) 2011-2012 celeron55, Perttu Ahola <celeron55@gmail.com>
GNU Lesser General Public License as published by
the Free Software Foundation; either version 2.1 of the License, or
(at your option) any later version.