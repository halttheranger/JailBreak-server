Sounds:
sounds = default.node_sound_sand_defaults()

Mito551 (sounds) (CC BY-SA):

.png's:
default_desert_sand.png
VanessaE (WTFPL)

Code:
minetest/games/minetest_game/mods/default/mapgen.lua --> ore generation

Copyright (C) 2011-2012 celeron55, Perttu Ahola <celeron55@gmail.com>
GNU Lesser General Public License as published by
the Free Software Foundation; either version 2.1 of the License, or
(at your option) any later version.