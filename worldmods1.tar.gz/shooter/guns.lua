local addvectors = function (v1, v2)
	return {x=v1.x+v2.x, y=v1.y+v2.y, z=v1.z+v2.z}
end

minetest.register_craftitem("shooter:flamethrower", {
	description = "Flamethrower",
	inventory_image = "flamethrower.png",
	on_use = function (itemstack, player, pointed_thing)
		-- Throw fire
		local pos = player:getpos()
		local vel = player:get_look_dir()

		local rshift = {x = vel.z/8, z = -vel.x/8, y = 0}

		local minp = {x=pos.x, y=pos.y+1.6, z=pos.z}
		local maxp = {x=pos.x, y=pos.y+1.6, z=pos.z}
		minp = addvectors(minp, rshift)
		maxp = addvectors(maxp, rshift)

		local minvel = {x=vel.x*6-0.5, y=vel.y*6-0.5, z=vel.z*6-0.5}
		local maxvel = {x=vel.x*6+0.5, y=vel.y*6+0.5, z=vel.z*6+0.5}

		minetest.add_particlespawner(300, 0.2,
			minp, maxp,
			minvel, maxvel,
			{x=0, y=0, z=0}, {x=0, y=1, z=0},
			1.2, 2,
			0.1, 1,
			false, "fire_basic_flame.png")

		-- Make stuff burn
		local np = minp
		for i = 0, 5 do
			np = addvectors(np, vel)
			local node = minetest.env:get_node(np)
			if minetest.get_item_group(node.name, "flammable") ~= 0 then
				minetest.env:set_node(np, {name="fire:basic_flame"})
			end

			if node.name == "default:dirt_with_grass" then
				minetest.env:set_node(np, {name="default:dirt"})
			end
		end
	end
})

minetest.register_craftitem("shooter:flamethrower_plus", {
	description = "Super Flamethrower",
	inventory_image = "flamethrower_plus.png",
	on_use = function (itemstack, player, pointed_thing)
		-- Throw fire
		local pos = player:getpos()
		local vel = player:get_look_dir()

		local rshift = {x = vel.z/8, z = -vel.x/8, y = 0}

		local minp = {x=pos.x, y=pos.y+1.6, z=pos.z}
		local maxp = {x=pos.x, y=pos.y+1.6, z=pos.z}
		minp = addvectors(minp, rshift)
		maxp = addvectors(maxp, rshift)

		local minvel = {x=vel.x*6-0.5, y=vel.y*6-0.5, z=vel.z*6-0.5}
		local maxvel = {x=vel.x*6+0.5, y=vel.y*6+0.5, z=vel.z*6+0.5}

		minetest.add_particlespawner(1000, 0.3,
			minp, maxp,
			minvel, maxvel,
			{x=0, y=0, z=0}, {x=0, y=1, z=0},
			2.3, 3,
			0.2, 2,
			false, "fire_plus.png")

		-- Make stuff burn
		local np = minp
		for i = 0, 5 do
			np = addvectors(np, vel)
			local node = minetest.env:get_node(np)
			if minetest.get_item_group(node.name, "flammable") ~= 0 then
				minetest.env:set_node(np, {name="fire:basic_flame"})
			end

			if node.name == "default:dirt_with_grass" then
				minetest.env:set_node(np, {name="default:dirt"})
			end
		end
	end
})
local addvectors = function (v1, v2)
	return {x=v1.x+v2.x, y=v1.y+v2.y, z=v1.z+v2.z}
end

minetest.register_craftitem("shooter:flamethrower_diamond", {
	description = "Diamond Flamethrower",
	inventory_image = "diamond_flamethrower.png",
	on_use = function (itemstack, player, pointed_thing)
		-- Throw fire
		local pos = player:getpos()
		local vel = player:get_look_dir()

		local rshift = {x = vel.z/8, z = -vel.x/8, y = 0}

		local minp = {x=pos.x, y=pos.y+1.6, z=pos.z}
		local maxp = {x=pos.x, y=pos.y+1.6, z=pos.z}
		minp = addvectors(minp, rshift)
		maxp = addvectors(maxp, rshift)

		local minvel = {x=vel.x*6-0.5, y=vel.y*6-0.5, z=vel.z*6-0.5}
		local maxvel = {x=vel.x*6+0.5, y=vel.y*6+0.5, z=vel.z*6+0.5}

		minetest.add_particlespawner(500, 0.2,
			minp, maxp,
			minvel, maxvel,
			{x=0, y=0, z=0}, {x=0, y=1, z=0},
			1.2, 2,
			0.1, 1,
			false, "diamond.png")

		-- Make stuff burn
		local np = minp
		for i = 0, 5 do
			np = addvectors(np, vel)
			local node = minetest.env:get_node(np)
			if minetest.get_item_group(node.name, "flammable") ~= 0 then
				minetest.env:set_node(np, {name="default:diamondblock"})
			end

			if node.name == "default:dirt_with_grass" then
				minetest.env:set_node(np, {name="default:dirt"})
			end
		end
	end
})



shooter:register_weapon("shooter:handgun_airsoft", {
	description = "Airsoft Handgun",
	inventory_image = "handgun.png",
	rounds = 26,
	shots = 2,
	spec = {
		range = 100,
		step = 20,
		shots = 2,
		tool_caps = {full_punch_interval=0.3, damage_groups={fleshy=101}},
		groups = {fleshy=10, glass=9999999},
		sound = "handgun",
		particle = "halt_bullet.png",
	},
})
shooter:register_weapon("shooter:sniper_airsoft", {
	description = "Airsoft Sniper Rifle",
	inventory_image = "sniper.png",
	rounds = 31,
	shots = 1,
	spec = {
		range = 400,
		step = 20,
		shots = 2,
		tool_caps = {full_punch_interval=0.4, damage_groups={fleshy=117}},
		groups = {fleshy=17, glass=9999999},
		sound = "shooter_shotgun",
		particle = "halt_bullet.png",
	},
})


shooter:register_weapon("shooter:rifle_airsoft", {
	description = "Airsoft Rifle",
	inventory_image = "shooter_rifle.png",
	rounds = 21,
	shots = 3,
	spec = {
		range = 300,
		step = 30,
		tool_caps = {full_punch_interval=0.5, damage_groups={fleshy=311}},
		groups = {fleshy=3, glass=9999999},
		sound = "shooter_rifle",
		particle = "shooter_bullet.png",
	},
})
shooter:register_weapon("shooter:machine_airsoft", {
	description = "Airsoft Machine Gun",
	inventory_image = "machine.png",
	rounds = 16,
	shots = 20,
	spec = {
		range = 200,
		step = 20,
		tool_caps = {full_punch_interval=0.01, damage_groups={fleshy=511}},
		groups = {fleshy=5, glass=9999999},
		sound = "machinegun",
		particle = "shooter_bullet.png",
	},
})

shooter:register_weapon("shooter:turretgun_airsoft", {
	description = "Airsoft turretgun",
	inventory_image = "shooter_rocket_gun.png",
	rounds = 11,
	shots = 500,
	spec = {
		range = 200,
		step = 20,
		tool_caps = {full_punch_interval=0.001, damage_groups={fleshy=5, fire=5}},
		groups = {fleshy=5, glass=9999999},
		sound = "machinegun",
		particle = "shooter_bullet.png",
	},
})













shooter:register_weapon("shooter:turretgun", {
	description = "turretgun",
	inventory_image = "shooter_rocket_gun.png",
	rounds = 26,
	shots = 500,
	spec = {
		range = 200,
		step = 20,
		tool_caps = {full_punch_interval=0.001, damage_groups={fleshy=5000, fire=5000}},
		groups = {fleshy=5, glass=9999999},
		sound = "machinegun",
		particle = "shooter_bullet.png",
	},
})

shooter:register_weapon("shooter:pistol", {
	description = "Pistol",
	inventory_image = "shooter_pistol.png",
	rounds = 200,
	spec = {
		range = 100,
		step = 20,
		tool_caps = {full_punch_interval=0.5, damage_groups={fleshy=2}},
		groups = {fleshy=2, glass=9999999},
		sound = "shooter_pistol",
		particle = "shooter_cap.png",
	},
})
shooter:register_weapon("shooter:handgun", {
	description = "Handgun",
	inventory_image = "handgun.png",
	rounds = 300,
	spec = {
		range = 100,
		step = 20,
		shots = 2,
		tool_caps = {full_punch_interval=0.3, damage_groups={fleshy=10}},
		groups = {fleshy=10, glass=9999999},
		sound = "handgun",
		particle = "halt_bullet.png",
	},
})
shooter:register_weapon("shooter:handgun_5shot", {
	description = "Handgun",
	inventory_image = "handgun.png",
	rounds = 11,
	shots = 5,
	spec = {
		range = 100,
		step = 20,
		tool_caps = {full_punch_interval=0.3, damage_groups={fleshy=10}},
		groups = {fleshy=10, glass=9999999},
		sound = "handgun",
		particle = "halt_bullet.png",
	},
})
shooter:register_weapon("shooter:handgun_police", {
	description = "Handgun",
	inventory_image = "handgun.png",
	rounds = 300,
	shots = 2,
	spec = {
		range = 100,
		step = 20,
		tool_caps = {full_punch_interval=0.3, damage_groups={fleshy=300}},
		groups = {fleshy=300, glass=9999999},
		sound = "handgun",
		particle = "halt_bullet.png",
	},
})
shooter:register_weapon("shooter:sniper", {
	description = "Sniper Rifle",
	inventory_image = "sniper.png",
	rounds = 15,
	spec = {
		range = 400,
		step = 20,
		shots = 2,
		tool_caps = {full_punch_interval=0.5, damage_groups={fleshy=17}},
		groups = {fleshy=17, glass=9999999},
		sound = "shooter_shotgun",
		particle = "halt_bullet.png",
	},
})


shooter:register_weapon("shooter:rifle", {
	description = "Rifle",
	inventory_image = "shooter_rifle.png",
	rounds = 50,
	spec = {
		range = 300,
		step = 30,
		tool_caps = {full_punch_interval=0.5, damage_groups={fleshy=3}},
		groups = {fleshy=3, glass=9999999},
		sound = "shooter_rifle",
		particle = "shooter_bullet.png",
	},
})

shooter:register_weapon("shooter:machine", {
	description = "Super Machine Gun",
	inventory_image = "machine.png",
	rounds = 800,
	shots = 200,
	spec = {
		range = 200,
		step = 20,
		tool_caps = {full_punch_interval=0.01, damage_groups={fleshy=5}},
		groups = {fleshy=5, glass=9999999},
		sound = "machinegun",
		particle = "shooter_bullet.png",
	},
})

shooter:register_weapon("shooter:laser", {
	description = "Laser Gun",
	inventory_image = "lasergun.png",
	rounds = 400,
	spec = {
		range = 200,
		step = 20,
		tool_caps = {full_punch_interval=0.1, damage_groups={fleshy=14}},
		groups = {fleshy=14, glass=9999999},
		sound = "lasergun",
		particle = "laser.png",
	},
})


shooter:register_weapon("shooter:rapid", {
	description = "Machine Gun",
	inventory_image = "shooter_rifle.png",
	rounds = 400,
	shots = 5,
	spec = {
		range = 300,
		step = 30,
		tool_caps = {full_punch_interval=0.01, damage_groups={fleshy=6}},
		groups = {fleshy=6, glass=9999999},
		sound = "shooter_rifle",
		particle = "shooter_bullet.png",
	},
})

shooter:register_weapon("shooter:shotgun", {
	description = "Shotgun",
	inventory_image = "shooter_shotgun.png",
	rounds = 50,
	spec = {
		range = 50,
		step = 15,
		tool_caps = {full_punch_interval=1.5, damage_groups={fleshy=6}},
		groups = {fleshy=1, glass=9999999},
		sound = "shooter_shotgun",
		particle = "smoke_puff.png",
	},
})

shooter:register_weapon("shooter:machine_gun", {
	description = "Sub Machine Gun",
	inventory_image = "shooter_smgun.png",
	rounds = 50,
	shots = 4,
	spec = {
		range = 100,
		step = 20,
		tool_caps = {full_punch_interval=0.125, damage_groups={fleshy=2}},
		groups = {fleshy=2, glass=9999999},
		sound = "shooter_pistol",
		particle = "shooter_cap.png",
	},
})

minetest.register_craftitem("shooter:ammo", {
	description = "Ammo pack",
	inventory_image = "shooter_ammo.png",
})

if SHOOTER_ENABLE_CRAFTING == true then
	minetest.register_craft({
		output = "shooter:pistol 1 65535",
		recipe = {
			{"default:steel_ingot", "default:steel_ingot"},
			{"", "default:mese_crystal"},
		},
	})
	minetest.register_craft({
		output = "shooter:handgun 1 65535",
		recipe = {
			{"default:steel_ingot", "default:steel_ingot"},
			{"", "default:diamond"},
		},
	})
	minetest.register_craft({
		output = "shooter:rifle 1 65535",
		recipe = {
			{"default:steel_ingot", "", ""},
			{"", "default:bronze_ingot", ""},
			{"", "default:mese_crystal", "default:bronze_ingot"},
		},
	})
	minetest.register_craft({
		output = "shooter:rapid 1 65535",
		recipe = {
			{"default:steel_ingot", "", ""},
			{"", "default:bronze_ingot", ""},
			{"", "default:diamond", "default:bronze_ingot"},
		},
	})
	minetest.register_craft({
		output = "shooter:shotgun 1 65535",
		recipe = {
			{"default:steel_ingot", "", ""},
			{"", "default:steel_ingot", ""},
			{"", "default:mese_crystal", "default:bronze_ingot"},
		},
	})
	minetest.register_craft({
		output = "shooter:laser 1 65535",
		recipe = {
			{"default:steel_ingot", "", ""},
			{"", "default:steel_ingot", "default:diamond"},
			{"", "default:mese_crystal", "default:bronze_ingot"},
		},
	})
	minetest.register_craft({
		output = "shooter:sniper 1 65535",
		recipe = {
			{"default:steel_ingot", "", ""},
			{"", "default:steel_ingot", ""},
			{"", "default:diamond", "default:bronze_ingot"},
		},
	})
	minetest.register_craft({
		output = "shooter:machine_gun 1 65535",
		recipe = {
			{"default:steel_ingot", "default:steel_ingot", "default:steel_ingot"},
			{"", "default:bronze_ingot", "default:mese_crystal"},
			{"", "default:bronze_ingot", ""},
		},
	})
	minetest.register_craft({
		output = "shooter:machine 1 65535",
		recipe = {
			{"default:steel_ingot", "default:steel_ingot", "default:steel_ingot"},
			{"", "default:bronze_ingot", "default:diamond"},
			{"", "default:bronze_ingot", ""},
		},
	})
	minetest.register_craft({
		output = "shooter:flamethrower 1",
		recipe = {
			{"default:steel_ingot", "default:steel_ingot", "default:steel_ingot"},
			{"", "default:copper_ingot", "default:diamond"},
			{"", "default:copper_ingot", ""},
		},
	})
	minetest.register_craft({
		output = "shooter:ammo",
		recipe = {
			{"tnt:gunpowder", "default:bronze_ingot"},
		},
	})
end

local rounds_update_time = 0

minetest.register_globalstep(function(dtime)
	shooter.time = shooter.time + dtime
	if shooter.time - rounds_update_time > SHOOTER_ROUNDS_UPDATE_TIME then
		for i, round in ipairs(shooter.rounds) do
			if shooter:process_round(round) or round.dist > round.def.range then
				table.remove(shooter.rounds, i)
			else
				local v = vector.multiply(round.ray, round.def.step)
				shooter.rounds[i].pos = vector.add(round.pos, v)
				shooter.rounds[i].dist = round.dist + round.def.step
			end
		end
		rounds_update_time = shooter.time
	end
	if shooter.time > 100000 then
		shooter.shots = {}
		rounds_update_time = 0
		shooter.reload_time = 0
		shooter.update_time = 0
		shooter.time = 0
	end
end)

