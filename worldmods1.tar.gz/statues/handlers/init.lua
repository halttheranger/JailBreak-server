local handlerpath = statues.modpath .. "/handlers/"

-- nodebox arithmetics and helpers
-- (please keep non-generic nodeboxes with their node definition)
dofile(handlerpath.."nodeboxes.lua")

-- expand and unexpand decor
dofile(handlerpath.."expansion.lua")

-- glue it all together into a registration function
dofile(handlerpath.."registration.lua")

dofile(handlerpath.."sit.lua")
