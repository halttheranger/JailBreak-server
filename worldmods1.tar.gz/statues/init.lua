-- Home Decor mod by VanessaE
--
-- Mostly my own code, with bits and pieces lifted from Minetest's default
-- lua files and from ironzorg's flowers mod.  Many thanks to GloopMaster
-- for helping me figure out the inventories used in the nightstands/dressers.
--
-- The code for ovens, nightstands, refrigerators are basically modified
-- copies of the code for chests and furnaces.

local modpath = minetest.get_modpath("statues")

statues = {
	modpath = modpath,

	-- Boilerplate to support localized strings if intllib mod is installed.
	gettext = rawget(_G, "intllib") and intllib.Getter() or function(s) return s end,

	-- infinite stacks
	expect_infinite_stacks = minetest.setting_getbool("creative_mode") and not minetest.get_modpath("unified_inventory")
}

-- Determine if the item being pointed at is the underside of a node (e.g a ceiling)
function statues.find_ceiling(itemstack, placer, pointed_thing)
	-- most of this is copied from the rotate-and-place function in builtin
	local unode = core.get_node_or_nil(pointed_thing.under)
	if not unode then
		return
	end
	local undef = core.registered_nodes[unode.name]
	if undef and undef.on_rightclick then
		undef.on_rightclick(pointed_thing.under, unode, placer,
				itemstack, pointed_thing)
		return
	end
	local pitch = placer:get_look_pitch()
	local fdir = core.dir_to_facedir(placer:get_look_dir())
	local wield_name = itemstack:get_name()

	local above = pointed_thing.above
	local under = pointed_thing.under
	local iswall = (above.y == under.y)
	local isceiling = not iswall and (above.y < under.y)
	local anode = core.get_node_or_nil(above)
	if not anode then
		return
	end
	local pos = pointed_thing.above
	local node = anode

	if undef and undef.buildable_to then
		pos = pointed_thing.under
		node = unode
		iswall = false
	end

	if core.is_protected(pos, placer:get_player_name()) then
		core.record_protection_violation(pos,
				placer:get_player_name())
		return
	end

	local ndef = core.registered_nodes[node.name]
	if not ndef or not ndef.buildable_to then
		return
	end
	return isceiling, pos
end
dofile(modpath.."/handlers/init.lua")

-- the statues are comming




local S = statues.gettext

--1-5


statues.register("goldarmor", {
	mesh = "character.b3d",
	tiles = { "goldarmorstatue.png" },
	inventory_image = "goldarmorstatue.png",
	description = S("statue (goldarmor)"),
	groups = {snappy=3,cracky=2},
	visual_size ={x=1, y=1},
	sounds = default.node_sound_stone_defaults(),
	selection_box = statues.nodebox.slab_y(2),
	collision_box = statues.nodebox.slab_y(2),
	light_source = 100,
	expand = { top="placeholder" },
	infotext=S("goldarmorstatue")
})

minetest.register_craft({
	output = "statues:goldarmor 5",
	recipe = {
		{"", "default:stone", ""},
		{"dye:yellow", "default:stone", "dye:yellow"},
		{"", "default:stone", ""},
	}
})




statues.register("goodcloak", {
	mesh = "character.b3d",
	tiles = { "goodcloak.png" },
	inventory_image = "goodcloak.png",
	description = S("statue (goodcloak)"),
	groups = {snappy=3,cracky=2},
	visual_size ={x=1, y=1},
	sounds = default.node_sound_stone_defaults(),
	selection_box = statues.nodebox.slab_y(2),
	collision_box = statues.nodebox.slab_y(2),
	light_source = 100,
	expand = { top="placeholder" },
	infotext=S("goodcloakstatue")
})

minetest.register_craft({
	output = "statues:goodcloak 5",
	recipe = {
		{"", "default:stone", ""},
		{"dye:white", "default:stone", "dye:white"},
		{"", "default:stone", ""},
	}
})





statues.register("evilcloak", {
	mesh = "character.b3d",
	tiles = { "evilcloak.png" },
	inventory_image = "evilcloak.png",
	description = S("statue (evilcloak)"),
	groups = {snappy=3,cracky=2},
	visual_size ={x=1, y=1},
	sounds = default.node_sound_stone_defaults(),
	selection_box = statues.nodebox.slab_y(2),
	collision_box = statues.nodebox.slab_y(2),
	light_source = 100,
	expand = { top="placeholder" },
	infotext=S("evilcloakstatue")
})

minetest.register_craft({
	output = "statues:evilcloak 5",
	recipe = {
		{"", "default:stone", ""},
		{"dye:red", "default:stone", "dye:red"},
		{"", "default:stone", ""},
	}
})





statues.register("weeping", {
	mesh = "character.b3d",
	tiles = { "weeping.png" },
	inventory_image = "weeping.png",
	description = S("statue (weeping)"),
	groups = {snappy=3,cracky=2},
	visual_size ={x=1, y=1},
	sounds = default.node_sound_stone_defaults(),
	selection_box = statues.nodebox.slab_y(2),
	collision_box = statues.nodebox.slab_y(2),
	light_source = 100,
	expand = { top="placeholder" },
	infotext=S("weepingstatue")
})

minetest.register_craft({
	output = "statues:weeping 5",
	recipe = {
		{"", "default:stone", ""},
		{"dye:grey", "default:stone", "dye:grey"},
		{"", "default:stone", ""},
	}
})






statues.register("flowerbluedress", {
	mesh = "character.b3d",
	tiles = { "flowerbluedress.png" },
	inventory_image = "flowerbluedress.png",
	description = S("statue (flowerbluedress)"),
	groups = {snappy=3,cracky=2},
	visual_size ={x=1, y=1},
	sounds = default.node_sound_stone_defaults(),
	selection_box = statues.nodebox.slab_y(2),
	collision_box = statues.nodebox.slab_y(2),
	light_source = 100,
	expand = { top="placeholder" },
	infotext=S("flowerbluedressstatue")
})

minetest.register_craft({
	output = "statues:flowerbluedress 5",
	recipe = {
		{"", "default:stone", ""},
		{"dye:blue", "default:stone", "dye:blue"},
		{"", "default:stone", ""},
	}
})


--5-10

statues.register("evilfire", {
	mesh = "character.b3d",
	tiles = { "evilfire.png" },
	inventory_image = "evilfire.png",
	description = S("statue (evilfire)"),
	groups = {snappy=3,cracky=2},
	visual_size ={x=1, y=1},
	sounds = default.node_sound_stone_defaults(),
	selection_box = statues.nodebox.slab_y(2),
	collision_box = statues.nodebox.slab_y(2),
	light_source = 100,
	expand = { top="placeholder" },
	infotext=S("evilfirestatue")
})

minetest.register_craft({
	output = "statues:evilfire 5",
	recipe = {
		{"", "default:stone", ""},
		{"dye:orange", "default:stone", "dye:orange"},
		{"", "default:stone", ""},
	}
})



statues.register("shadychar", {
	mesh = "character.b3d",
	tiles = { "shadychar.png" },
	inventory_image = "shadychar.png",
	description = S("statue (shadychar)"),
	groups = {snappy=3,cracky=2},
	visual_size ={x=1, y=1},
	sounds = default.node_sound_stone_defaults(),
	selection_box = statues.nodebox.slab_y(2),
	collision_box = statues.nodebox.slab_y(2),
	light_source = 100,
	expand = { top="placeholder" },
	infotext=S("shadycharstatue")
})

minetest.register_craft({
	output = "statues:shadychar 5",
	recipe = {
		{"", "default:stone", ""},
		{"dye:black", "default:stone", "dye:black"},
		{"", "default:stone", ""},
	}
})



statues.register("stormtroop", {
	mesh = "character.b3d",
	tiles = { "stormtroop.png" },
	inventory_image = "stormtroop.png",
	description = S("statue (stormtroop)"),
	groups = {snappy=3,cracky=2},
	visual_size ={x=1, y=1},
	sounds = default.node_sound_stone_defaults(),
	selection_box = statues.nodebox.slab_y(2),
	collision_box = statues.nodebox.slab_y(2),
	light_source = 100,
	expand = { top="placeholder" },
	infotext=S("stormtroopstatue")
})

minetest.register_craft({
	output = "statues:stormtroop 5",
	recipe = {
		{"", "default:stone", ""},
		{"dye:black", "default:stone", "dye:white"},
		{"", "default:stone", ""},
	}
})



statues.register("stormtrooper", {
	mesh = "character.b3d",
	tiles = { "stormtrooper.png" },
	inventory_image = "stormtrooper.png",
	description = S("statue (stormtrooper)"),
	groups = {snappy=3,cracky=2},
	visual_size ={x=1, y=1},
	light_source = 100,
	sounds = default.node_sound_stone_defaults(),
	selection_box = statues.nodebox.slab_y(2),
	collision_box = statues.nodebox.slab_y(2),
	expand = { top="placeholder" },
	infotext=S("stormtrooperstatue")
})

minetest.register_craft({
	output = "statues:stormtrooper 5",
	recipe = {
		{"", "default:stone", ""},
		{"dye:white", "default:stone", "dye:black"},
		{"", "default:stone", ""},
	}
})



statues.register("witchking", {
	mesh = "character.b3d",
	tiles = { "witchking.png" },
	inventory_image = "witchking.png",
	description = S("statue (witchking)"),
	light_source = 100,
	groups = {snappy=3,cracky=2},
	visual_size ={x=1, y=1},
	sounds = default.node_sound_stone_defaults(),
	selection_box = statues.nodebox.slab_y(2),
	collision_box = statues.nodebox.slab_y(2),
	expand = { top="placeholder" },
	infotext=S("witchkingstatue")
})

minetest.register_craft({
	output = "statues:witchking 5",
	recipe = {
		{"", "default:stone", ""},
		{"dye:black", "default:stone", "dye:grey"},
		{"", "default:stone", ""},
	}
})



--10-15

statues.register("clanmaster", {
	mesh = "character.b3d",
	tiles = { "clanmaster.png" },
	inventory_image = "clanmaster.png",
	description = S("statue (clanmaster)"),
	light_source = 100,
	groups = {snappy=3,cracky=2},
	visual_size ={x=1, y=1},
	sounds = default.node_sound_stone_defaults(),
	selection_box = statues.nodebox.slab_y(2),
	collision_box = statues.nodebox.slab_y(2),
	expand = { top="placeholder" },
	infotext=S("clanmasterstatue")
})

minetest.register_craft({
	output = "statues:clanmaster 5",
	recipe = {
		{"", "default:stone", ""},
		{"dye:brown", "default:stone", "dye:black"},
		{"", "default:stone", ""},
	}
})


statues.register("fishywet", {
	mesh = "character.b3d",
	tiles = { "fishywet.png" },
	inventory_image = "fishywet.png",
	description = S("statue (fishywet)"),
	light_source = 100,
	groups = {snappy=3,cracky=2},
	visual_size ={x=1, y=1},
	sounds = default.node_sound_stone_defaults(),
	selection_box = statues.nodebox.slab_y(2),
	collision_box = statues.nodebox.slab_y(2),
	expand = { top="placeholder" },
	infotext=S("fishywetstatue")
})

minetest.register_craft({
	output = "statues:fishywet 5",
	recipe = {
		{"", "default:stone", ""},
		{"dye:black", "default:stone", "dye:yellow"},
		{"", "default:stone", ""},
	}
})


statues.register("hobbitpower", {
	mesh = "character.b3d",
	tiles = { "hobbitpower.png" },
	inventory_image = "hobbitpower.png",
	description = S("statue (hobbitpower)"),
	light_source = 100,
	groups = {snappy=3,cracky=2},
	visual_size ={x=1, y=1},
	sounds = default.node_sound_stone_defaults(),
	selection_box = statues.nodebox.slab_y(2),
	collision_box = statues.nodebox.slab_y(2),
	expand = { top="placeholder" },
	infotext=S("hobbitpowerstatue")
})

minetest.register_craft({
	output = "statues:hobbitpower 5",
	recipe = {
		{"", "default:stone", ""},
		{"dye:black", "default:stone", "dye:red"},
		{"", "default:stone", ""},
	}
})


statues.register("oldcoder", {
	mesh = "character.b3d",
	tiles = { "oldcoder.png" },
	inventory_image = "oldcoder.png",
	description = S("statue (oldcoder)"),
	light_source = 100,
	groups = {snappy=3,cracky=2},
	visual_size ={x=1, y=1},
	sounds = default.node_sound_stone_defaults(),
	selection_box = statues.nodebox.slab_y(2),
	collision_box = statues.nodebox.slab_y(2),
	expand = { top="placeholder" },
	infotext=S("oldcoderstatue")
})

minetest.register_craft({
	output = "statues:oldcoder 5",
	recipe = {
		{"", "default:stone", ""},
		{"dye:white", "default:stone", "dye:brown"},
		{"", "default:stone", ""},
	}
})


statues.register("thomass", {
	mesh = "character.b3d",
	tiles = { "thomass.png" },
	inventory_image = "thomass.png",
	description = S("statue (thomass)"),
	light_source = 100,
	groups = {snappy=3,cracky=2},
	visual_size ={x=1, y=1},
	sounds = default.node_sound_stone_defaults(),
	selection_box = statues.nodebox.slab_y(2),
	collision_box = statues.nodebox.slab_y(2),
	expand = { top="placeholder" },
	infotext=S("thomassstatue")
})

minetest.register_craft({
	output = "statues:thomass 5",
	recipe = {
		{"", "default:stone", ""},
		{"dye:grey", "default:stone", "dye:white"},
		{"", "default:stone", ""},
	}
})

