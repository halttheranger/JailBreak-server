-- Animals

dofile(minetest.get_modpath("pmobs").."/wolf.lua") -- KrupnoPavel
if minetest.setting_get("log_mods") then
    minetest.log("action", "pmobs loaded")
end
