Death Messages        
==============

A Minetest mod which sends a chat message when a player dies.

Version: 0.1.2 beta

License of source code: 
GPL v3

See LICENSE.txt for full legal text

