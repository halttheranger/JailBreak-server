local function parse_param(name, param)
    local modname, level = param:match("^(%S+)%s(%S+)$")
    if not modname then
        return false, "Incorrect usage."
    end
    local privset = minetest.setting_get("mod_privs."..level)
    if not privset then
        return false, "Invalid level."
    end
    return modname, privset
end

minetest.register_chatcommand("add_mod", {
    params = "<name> <level>",
    description = "Adds a moderator",
    privs = {privs=true},
    func = function(name, param)
        local modname, privset = parse_param(name, param)
        if type(modname) ~= "string" then
            return modname, privset
        end
        return minetest.chatcommands.grant.func(name, modname.." "..privset)
    end,
})

minetest.register_chatcommand("remove_mod", {
    params = "<name> <level>",
    description = "Removes a moderator",
    privs = {privs=true},
    func = function(name, param)
        local modname, privset = parse_param(name, param)
        if type(modname) ~= "string" then
            return modname, privset
        end
        return minetest.chatcommands.revoke.func(name, modname.." "..privset)
    end,
})
