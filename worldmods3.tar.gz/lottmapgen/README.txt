paragenv7 0.3.1 by paramat
For latest stable Minetest and back to 0.4.8
Depends default
Licenses: code WTFPL, textures CC BY-SA

For use with mapgen v7 stone terrain.