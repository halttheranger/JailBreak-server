minetest.register_alias ("lottblocks:bell"               , "lottmusic:bell"               )
minetest.register_alias ("lottblocks:bellitem"           , "lottmusic:bellitem"           )
minetest.register_alias ("lottblocks:bighorn"            , "lottmusic:bighorn"            )
minetest.register_alias ("lottblocks:bronze_gong"        , "lottmusic:bronze_gong"        )
minetest.register_alias ("lottblocks:dwarf_harp"         , "lottmusic:dwarf_harp"         )
minetest.register_alias ("lottblocks:dwarf_harp_strings" , "lottmusic:dwarf_harp_strings" )
minetest.register_alias ("lottblocks:gong"               , "lottmusic:gong"               )
minetest.register_alias ("lottblocks:smallhorn"          , "lottmusic:smallhorn"          )
minetest.register_alias ("lottblocks:trumpet"            , "lottmusic:trumpet"            )
minetest.register_alias ("lottblocks:whistle_alder"      , "lottmusic:whistle_alder"      )
minetest.register_alias ("lottblocks:whistle_birch"      , "lottmusic:whistle_birch"      )
minetest.register_alias ("lottblocks:whistle_jungle"     , "lottmusic:whistle_jungle"     )
minetest.register_alias ("lottblocks:whistle_lebethron"  , "lottmusic:whistle_lebethron"  )
minetest.register_alias ("lottblocks:whistle_mallorn"    , "lottmusic:whistle_mallorn"    )
minetest.register_alias ("lottblocks:whistle_pine"       , "lottmusic:whistle_pine"       )
minetest.register_alias ("lottblocks:whistle_wood"       , "lottmusic:whistle_wood"       )

minetest.register_node ("lottmusic:dwarf_harp", {
    description = "Dwarvern Harp",
    tiles       = {
"lottmusic_harp1.png" , "lottmusic_harp2.png" , "lottmusic_harp3.png" ,
"lottmusic_harp4.png" , "lottmusic_harp5.png" , "lottmusic_harp6.png" ,
    } ,
    drawtype    = "nodebox" ,
    paramtype   = "light"   ,
    paramtype2  = "facedir" ,
    on_punch    = function (pos)
        minetest.sound_play ("lottmusic_harp", {
            pos               = pos ,
            max_hear_distance = 25  ,
            gain              =  1  ,
        })
    end,
    node_box = {
        type = "fixed" ,
        fixed = {
            {-0.3125, -0.5, -0.0625, 0.125, -0.375, 0.125}, -- NodeBox1
            {-0.1875, -0.375, -0.0625, 0.1875, -0.25, 0.125}, -- NodeBox2
            {-0.0625, -0.25, -0.0625, 0.25, -0.125, 0.125}, -- NodeBox3
            {0.0625, -0.125, -0.0625, 0.3125, 0, 0.125}, -- NodeBox4
            {0.1875, -0.0625, -0.0625, 0.375, 0.125, 0.125}, -- NodeBox5
            {0.3125, 0.0625, -0.0625, 0.4375, 0.25, 0.125}, -- NodeBox6
            {0.4375, 0.25, -0.0625, 0.5, 0.375, 0.125}, -- NodeBox7
            {0.375, 0.375, -0.0625, 0.4375, 0.4375, 0.125}, -- NodeBox8
            {-0.1875, 0.4375, -0.0625, 0.375, 0.5, 0.125}, -- NodeBox9
            {-0.375, -0.375, -0.0625, -0.3125, -0.3125, 0.125}, -- NodeBox10
            {-0.4375, -0.3125, -0.0625, -0.375, 0.25, 0.125}, -- NodeBox11
            {-0.375, 0.25, -0.0625, -0.3125, 0.3125, 0.125}, -- NodeBox12
            {-0.3125, 0.3125, -0.0625, -0.25, 0.375, 0.125}, -- NodeBox13
            {-0.25, 0.375, -0.0625, -0.1875, 0.4375, 0.125}, -- NodeBox14
            {-0.3125, -0.375, 0, -0.25, 0.3125, 0.0625}, -- NodeBox15
            {-0.1875, -0.25, 0, -0.125, 0.4375, 0.0625}, -- NodeBox16
            {-0.0625, -0.125, 0, 0, 0.4375, 0.0625}, -- NodeBox17
            {0.0625, 0, 0, 0.125, 0.4375, 0.0625}, -- NodeBox18
            {0.1875, 0.09375, 0, 0.25, 0.4375, 0.0625}, -- NodeBox19
            {0.3125, 0.25, 0, 0.375, 0.4375, 0.0625}, -- NodeBox20
        }
    },
    selection_box = {
        type = "fixed",
        fixed = {
            {-0.5, -0.5, -0.0625, 0.5, 0.5, 0.125}, -- NodeBox1
        }
    },
    groups = {instrument=1, cracky=1}
})

minetest.register_craftitem ("lottmusic:dwarf_harp_strings", {
    description     = "Dwarvern Harp Strings"      ,
    inventory_image = "lottmusic_harp_strings.png" ,
})

minetest.register_craft ({
    output = "lottmusic:dwarf_harp_strings" ,
    recipe = {
{ "farming:string" , "lottores:silver_ingot" , "farming:string" } ,
{ "farming:string" , "lottores:silver_ingot" , "farming:string" } ,
{ "farming:string" , "lottores:silver_ingot" , "farming:string" } ,
    }
})

minetest.register_craft ({
    output = "lottmusic:dwarf_harp",
    recipe = {
{ ""                   , "default:gold_ingot"           , ""                   } ,
{ "default:gold_ingot" , "lottmusic:dwarf_harp_strings" , "default:gold_ingot" } ,
{ "default:gold_ingot" , "default:gold_ingot"           , ""                   } ,
    }
})

local whistle = {
    { "birch", "D", "lottplants:birchwood"},
    { "mallorn", "Eb", "lottplants:mallornwood"},
    { "wood", "C", "default:wood"},
    { "jungle", "G", "default:junglewood"},
    { "pine", "Bb", "lottplants:pinewood"},
    { "lebethron", "A", "lottplants:lebethronwood"},
    { "alder", "F", "lottplants:alderwood"},
}

for _, row in ipairs(whistle) do
    local wood = row[1]
    local note = row[2]
    local craftwood = row[3]
    minetest.register_craftitem ("lottmusic:whistle_" .. wood, {
        description = wood:gsub("^%l", string.upper) .. " (Note " .. note .. ") Whistle",
        inventory_image = "lottmusic_" .. wood .. "_whistle.png",
        on_use = function(itemstack, user)
            minetest.sound_play(note, {
                pos = user:getpos(),
                max_hear_distance = 20,
                gain = 1,
            })
        end,
        groups = {instrument=1}
    })

    minetest.register_craft ({
        output = "lottmusic:whistle_" .. wood ,
        recipe = {
{ craftwood , ""        , ""                      } ,
{ ""        , craftwood , ""                      } ,
{ ""        , ""        , "lottores:silver_ingot" } ,
        }
    })
end

-- [Gold] Gong

minetest.register_node("lottmusic:gong", {
    description = "Gong",
    tiles = {"default_gold_block.png"},
    drawtype = "nodebox",
    paramtype = "light",
    paramtype2 = "facedir",
    on_punch = function(pos)
        minetest.sound_play("lottmusic_gong", {
            pos=pos,
            max_hear_distance = 150,
            gain = 1,
        })
    end,
    node_box = {
        type = "fixed",
        fixed = {
            {-0.5, 0.4375, -0.0625, 0.5, 0.5, 0.0625}, -- NodeBox1
            {0.4375, -0.5, -0.0625, 0.5, 0.5, 0.0625}, -- NodeBox2
            {-0.5, -0.5, -0.0625, -0.4375, 0.5, 0.0625}, -- NodeBox3
            {-0.1875, -0.1875, -0.0625, 0.1875, 0.1875, 0}, -- NodeBox5
            {-0.375, -0.3125, 0, -0.1875, 0.3125, 0.0625}, -- NodeBox6
            {0.125, -0.3125, 0, 0.3125, 0.3125, 0.0625}, -- NodeBox7
            {-0.3125, 0.125, 0, 0.3125, 0.3125, 0.0625}, -- NodeBox8
            {-0.375, -0.3125, 0, 0.3125, -0.125, 0.0625}, -- NodeBox9
            {-0.3125, 0.25, 0, -0.25, 0.5, 0.0625}, -- NodeBox10
            {0.1875, 0.25, 0, 0.25, 0.5, 0.0625}, -- NodeBox11
        }
    },
    selection_box = {
        type = "fixed",
        fixed = {
            {-0.5, -0.5, -0.0625, 0.5, 0.5, 0.125}, -- NodeBox1
        }
    },
    groups = {instrument=1, cracky=1}
})

minetest.register_craft ({
    output = "lottmusic:gong" ,
    recipe = {
{ "default:stick" , "default:stick"      , "default:stick" } ,
{ "default:stick" , "default:gold_ingot" , "default:stick" } ,
{ "default:stick" , ""                   , "default:stick" } ,
    }
})

-- Trumpet

minetest.register_craftitem ("lottmusic:trumpet", {
    description     = "Trumpet" ,
    inventory_image = "lottmusic_trumpet.png" ,
    on_use          = function (itemstack, user)
        minetest.sound_play ("lottmusic_trumpet", {
            pos = user:getpos()     ,
            max_hear_distance = 150 ,
            gain              =   4 ,
        })
    end ,
    groups = {instrument=1}
})

minetest.register_craft ({
    output = "lottmusic:trumpet" ,
    recipe = {
{ "default:gold_ingot" , ""                   , ""                   } ,
{ "default:gold_ingot" , "default:gold_ingot" , "default:gold_ingot" } ,
{ "default:gold_ingot" , "default:gold_ingot" , ""                   } ,
    }
})

-- Fanfare

minetest.register_craftitem ("lottmusic:fanfare", {
    description     = "Fanfare" ,
    inventory_image = "lottmusic_fanfare.png" ,
    on_use          = function (itemstack, user)
        minetest.sound_play ("lottmusic_fanfare", {
            pos = user:getpos()     ,
            max_hear_distance = 150 ,
            gain              =   4 ,
        })
    end ,
    groups = {instrument=1}
})

minetest.register_craft ({
    output = "lottmusic:fanfare" ,
    recipe = {
{ "default:gold_ingot" , ""                   , ""                   } ,
{ "default:gold_ingot" , "default:gold_ingot" , "default:gold_ingot" } ,
{ "default:gold_ingot" , "group:wool"         , ""                   } ,
    }
})

--Small Horn

minetest.register_craftitem ("lottmusic:smallhorn", {
    description     = "Small Horn"         ,
    inventory_image = "lottmusic_horn.png" ,
    on_use          = function (itemstack, user)
        minetest.sound_play ("HornSmall", {
            pos               = user:getpos() ,
            max_hear_distance = 150           ,
            gain              = 1             ,
        })
    end,
    groups = {instrument=1}
})

minetest.register_craft ({
    output = "lottmusic:smallhorn",
    recipe = {
{ "group:wood" , ""           , ""              } ,
{ ""           , "group:wood" , ""              } ,
{ ""           , ""           , "default:stick" } ,
    }
})
        
--Big Horn
        
minetest.register_craftitem ("lottmusic:bighorn", {
    description = "Large Horn",
    inventory_image = "lottmusic_horn.png",
    on_use = function (itemstack, user)
        minetest.sound_play ("HornLarge", {
            pos               = user:getpos() ,
            max_hear_distance = 250           ,
            gain              =   1           ,
        })
    end,
    groups = {instrument=1}
})

minetest.register_craft({
        output = "lottmusic:bighorn",
        recipe = {
{ "group:wood"    , ""                    , "group:wood"    } ,
{ "group:wood"    , ""                    , "group:wood"    } ,
{ "default:stick" , "default:steel_ingot" , "default:stick" } ,
        }
})

--Bell

minetest.register_node("lottmusic:bell", {
    description = "Big Bell",
    tiles = {"default_gold_block.png"},
    drawtype = "nodebox",
    paramtype = "light",
    paramtype2 = "facedir",
    on_punch = function(pos)
        minetest.sound_play("BellLarge", {
            pos=pos,
            max_hear_distance = 1000,
            gain = 1,
        })
    end,
    node_box = {
        type = "fixed",
        fixed = {
            {-0.125, -0.5, -0.125, 0.125, -0.25, 0.125}, -- NodeBox1
            {-0.0625, -0.4375, -0.0625, 0.0625, 0.5, 0.0625}, -- NodeBox2
            {-0.5, -0.5, 0.4375, 0.5, -0.375, 0.5}, -- NodeBox3
            {-0.5, -0.5, -0.5, 0.5, -0.375, -0.4375}, -- NodeBox4
            {0.4375, -0.5, -0.5, 0.5, -0.375, 0.5}, -- NodeBox5
            {-0.5, -0.5, -0.5, -0.4375, -0.375, 0.5}, -- NodeBox6
            {-0.4375, -0.4375, -0.4375, -0.375, -0.125, 0.4375}, -- NodeBox7
            {-0.4375, -0.4375, 0.375, 0.4375, -0.125, 0.4375}, -- NodeBox8
            {-0.4375, -0.4375, -0.4375, 0.4375, -0.125, -0.375}, -- NodeBox9
            {0.375, -0.4375, -0.4375, 0.4375, -0.125, 0.4375}, -- NodeBox10
            {-0.375, -0.1875, -0.375, -0.3125, 0.25, 0.375}, -- NodeBox11
            {-0.375, -0.1875, 0.3125, 0.375, 0.25, 0.375}, -- NodeBox12
            {-0.375, -0.1875, -0.375, 0.375, 0.25, -0.3125}, -- NodeBox13
            {0.3125, -0.1875, -0.375, 0.375, 0.25, 0.375}, -- NodeBox14
            {-0.3125, 0.1875, -0.3125, 0.3125, 0.375, 0.3125}, -- NodeBox15
            {-0.1875, 0.375, -0.1875, 0.1875, 0.4375, 0.1875}, -- NodeBox16
        }
    },
    groups = {instrument=1, cracky=1}
})

minetest.register_craftitem("lottmusic:bellitem", {
    description = "Small Bell",
    inventory_image = "lottmusic_bellitem.png",
    on_use = function (itemstack, user)
        minetest.sound_play ("BellSmall", {
            pos               = user:getpos() ,
            max_hear_distance = 20            ,
            gain              = 1             ,
        })
    end,
})

minetest.register_craft({
    output = "lottmusic:bellitem",
    recipe = {
{"", "default:steel_ingot", ""},
{"default:gold_ingot", "default:steel_ingot", "default:gold_ingot"},
{"default:gold_ingot", "", "default:gold_ingot"}
    }
})

minetest.register_craft({
    output = "lottmusic:bell",
    recipe = {
{"group:wood", "group:wood", "group:wood" } ,
{"group:wood", "lottmusic:bellitem", "group:wood"} ,
{"group:wood", "", "group:wood"} ,
    }
})
